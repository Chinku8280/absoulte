-- ---------------------------------------------------------
		--
		-- SIMPLE SQL Dump
		-- 
		-- nawa (at) yahoo (dot) com
		--
		-- Host Connection Info: Localhost via UNIX socket
		-- Generation Time: October 06, 2023 at 08:56 AM ( UTC )
		-- PHP Version: 8.0.30
		--
		-- ---------------------------------------------------------


		SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
		SET time_zone = "+00:00";
		/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
		/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
		/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
		/*!40101 SET NAMES utf8 */;
		

		-- ---------------------------------------------------------
		--
		-- Table structure for table : `grouping`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `grouping` (
  `grouping_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `sub_department_id` int(11) NOT NULL,
  `grouping_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`grouping_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

		--
		-- Dumping data for table `grouping`
		--
		INSERT INTO `grouping` (`grouping_id`, `department_id`, `sub_department_id`, `grouping_name`, `created_at`) VALUES
(6, 1, 4, 'asd', '2023-10-05 09:20:55'),
(7, 1, 4, 'test', '2023-10-05 09:21:25'),
(8, 5, 8, 'te', '2023-10-05 09:21:43'),
(9, 1, 4, 'Testing', '2023-10-05 09:22:29');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `lead_contacts`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `lead_contacts` (
  `lead_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `postal_code` varchar(100) NOT NULL,
  `service_address` text NOT NULL,
  `unit_no` varchar(200) NOT NULL,
  `unit_area` varchar(300) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_datetime` varchar(200) NOT NULL,
  `modified_datetime` varchar(200) NOT NULL,
  PRIMARY KEY (`lead_contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

		--
		-- Dumping data for table `lead_contacts`
		--
		INSERT INTO `lead_contacts` (`lead_contact_id`, `lead_id`, `name`, `contact_no`, `email`, `postal_code`, `service_address`, `unit_no`, `unit_area`, `created_by`, `modified_by`, `created_datetime`, `modified_datetime`) VALUES
(1, 1, 'n1', 1230123012, 'n1@abc.com', 758036, '15 SENOKO WAY SENOKO INDUSTRIAL ESTATE SINGAPORE 758036', 1, '12sds', 1, 0, '02-06-2023 06:56:01', ''),
(2, 2, 'n2', 1230012300, 'n2@abc.com', 758036, '15 SENOKO WAY SENOKO INDUSTRIAL ESTATE SINGAPORE 758036', 3, 'sds', 1, 0, '02-06-2023 06:57:34', ''),
(3, 3, 'd1', 12345, 'd1@abc.com', 758036, '15 SENOKO WAY SENOKO INDUSTRIAL ESTATE SINGAPORE 758036', 1, 'sdsd', 1, 0, '02-06-2023 08:15:11', ''),
(4, 4, 'cxc', 12121, 'ss@aas.dd', 758036, '', 1, 'assa', 1, 0, '02-06-2023 09:06:16', ''),
(5, 5, 'sd', 122332, 'ss@ab.cc', 758036, '', 1, 'sas', 1, 0, '02-06-2023 09:13:39', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `leads`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `leads` (
  `lead_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_type` int(11) NOT NULL,
  `third_party` int(11) DEFAULT NULL,
  `company_name` varchar(250) DEFAULT NULL,
  `customer_name` varchar(250) NOT NULL,
  `contact_no` int(15) NOT NULL,
  `billing_address` varchar(250) NOT NULL,
  `email_address` varchar(250) NOT NULL,
  `created_by` int(5) NOT NULL,
  `enquiry_box` longtext DEFAULT NULL,
  `request_for_site_survey` int(2) DEFAULT NULL,
  `date_of_survey` varchar(250) DEFAULT NULL,
  `surveyor` varchar(250) DEFAULT NULL,
  `status` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

		--
		-- Dumping data for table `leads`
		--
		INSERT INTO `leads` (`lead_id`, `customer_type`, `third_party`, `company_name`, `customer_name`, `contact_no`, `billing_address`, `email_address`, `created_by`, `enquiry_box`, `request_for_site_survey`, `date_of_survey`, `surveyor`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'hhh', 'hh', 456123, 'hjjhjh', 'hh@gmail.com', 1, 'hhjhjhj', 1, '2023-06-09', 1, 'Pending', '2023-06-09 03:15:06', '2023-06-09 03:15:06');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `service_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `service_type` (
  `service_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_type` varchar(200) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `modified_datetime` datetime NOT NULL,
  PRIMARY KEY (`service_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

		--
		-- Dumping data for table `service_type`
		--
		INSERT INTO `service_type` (`service_type_id`, `service_type`, `created_by`, `modified_by`, `created_datetime`, `modified_datetime`) VALUES
(10, 'type1', 1, 0, '2023-06-07 01:45:27', '0000-00-00 00:00:00');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `services`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `services` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_type_id` int(11) NOT NULL,
  `service_name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `service_charge` varchar(200) NOT NULL,
  `uom` varchar(200) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `modified_datetime` datetime NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

		--
		-- Dumping data for table `services`
		--
		INSERT INTO `services` (`service_id`, `service_type_id`, `service_name`, `description`, `service_charge`, `uom`, `created_by`, `modified_by`, `created_datetime`, `modified_datetime`) VALUES
(1, 10, 's1', 'ssss', 1000, 'dd', 1, 1, '2023-06-07 02:02:45', '2023-06-07 00:00:00'),
(2, 10, 's1', '', 1000, 'we', 1, 0, '2023-06-07 02:04:00', '0000-00-00 00:00:00');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `users`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL COMMENT 'date when acccount was deleted',
  `creatorid` int(11) DEFAULT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `profile_img` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `country` varchar(200) NOT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `clientid` int(11) DEFAULT NULL COMMENT 'for client users',
  `account_owner` varchar(10) DEFAULT 'no' COMMENT 'yes | no',
  `primary_admin` varchar(10) DEFAULT 'no' COMMENT 'yes | no (only 1 primary admin - created during setup)',
  `avatar_directory` varchar(100) DEFAULT NULL,
  `avatar_filename` varchar(100) DEFAULT NULL,
  `type` varchar(10) NOT NULL COMMENT 'client | team |contact',
  `status` varchar(20) DEFAULT 'active' COMMENT 'active|suspended|deleted',
  `role_id` int(11) NOT NULL DEFAULT 2 COMMENT 'for team users',
  `last_seen` varchar(250) DEFAULT NULL,
  `theme` varchar(100) DEFAULT 'default',
  `last_ip_address` varchar(100) DEFAULT NULL,
  `social_facebook` varchar(200) DEFAULT NULL,
  `social_twitter` varchar(200) DEFAULT NULL,
  `social_linkedin` varchar(200) DEFAULT NULL,
  `social_github` varchar(200) DEFAULT NULL,
  `social_dribble` varchar(200) DEFAULT NULL,
  `pref_language` varchar(200) DEFAULT 'english' COMMENT 'english|french|etc',
  `pref_email_notifications` varchar(10) DEFAULT 'yes' COMMENT 'yes | no',
  `pref_leftmenu_position` varchar(50) DEFAULT 'collapsed' COMMENT 'collapsed | open',
  `pref_statspanel_position` varchar(50) DEFAULT 'collapsed' COMMENT 'collapsed | open',
  `pref_filter_own_tasks` varchar(50) DEFAULT 'no' COMMENT 'Show only a users tasks in the tasks list',
  `pref_filter_own_projects` varchar(50) DEFAULT 'no' COMMENT 'Show only a users projects in the projects list',
  `pref_filter_own_leads` varchar(50) DEFAULT 'no' COMMENT 'Show only a users projects in the leads list',
  `pref_view_tasks_layout` varchar(50) DEFAULT 'kanban' COMMENT 'list|kanban',
  `pref_view_leads_layout` varchar(50) DEFAULT 'kanban' COMMENT 'list|kanban',
  `remember_token` varchar(150) DEFAULT NULL,
  `forgot_password_token` varchar(150) DEFAULT NULL COMMENT 'random token',
  `forgot_password_token_expiry` datetime DEFAULT NULL,
  `force_password_change` varchar(10) DEFAULT 'no' COMMENT 'yes|no',
  `notifications_system` varchar(10) DEFAULT 'no' COMMENT 'no| yes | yes_email [everyone] NB: database defaults for all notifications are ''no'' actual values must be set in the settings config file',
  `notifications_new_project` varchar(10) DEFAULT 'no' COMMENT 'no| yes_email [client]',
  `notifications_projects_activity` varchar(10) DEFAULT 'no' COMMENT 'no | yes | yes_email [everyone]',
  `notifications_billing_activity` varchar(10) DEFAULT 'no' COMMENT 'no | yes | yes_email |[team]',
  `notifications_new_assignement` varchar(10) DEFAULT 'no' COMMENT 'no | yes | yes_email [team]',
  `notifications_leads_activity` varchar(10) DEFAULT 'no' COMMENT 'no | yes | yes_email [team]',
  `notifications_tasks_activity` varchar(10) DEFAULT 'no' COMMENT 'no | yes | yes_email  [everyone]',
  `notifications_tickets_activity` varchar(10) DEFAULT 'no' COMMENT 'no | yes | yes_email  [everyone]',
  `thridparty_stripe_customer_id` varchar(150) DEFAULT NULL COMMENT 'optional - when customer pays via ',
  `dashboard_access` varchar(150) DEFAULT 'yes' COMMENT 'yes|no',
  `welcome_email_sent` varchar(150) DEFAULT 'no' COMMENT 'yes|no',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `primary_contact` (`account_owner`),
  KEY `type` (`type`),
  KEY `role_id` (`role_id`),
  KEY `email` (`email`),
  KEY `dashboard_access` (`dashboard_access`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci COMMENT='[truncate] except user id 0 & 1';

		--
		-- Dumping data for table `users`
		--
		INSERT INTO `users` (`id`, `created`, `updated`, `deleted`, `creatorid`, `username`, `email`, `password`, `first_name`, `last_name`, `profile_img`, `gender`, `address`, `country`, `remark`, `phone`, `position`, `clientid`, `account_owner`, `primary_admin`, `avatar_directory`, `avatar_filename`, `type`, `status`, `role_id`, `last_seen`, `theme`, `last_ip_address`, `social_facebook`, `social_twitter`, `social_linkedin`, `social_github`, `social_dribble`, `pref_language`, `pref_email_notifications`, `pref_leftmenu_position`, `pref_statspanel_position`, `pref_filter_own_tasks`, `pref_filter_own_projects`, `pref_filter_own_leads`, `pref_view_tasks_layout`, `pref_view_leads_layout`, `remember_token`, `forgot_password_token`, `forgot_password_token_expiry`, `force_password_change`, `notifications_system`, `notifications_new_project`, `notifications_projects_activity`, `notifications_billing_activity`, `notifications_new_assignement`, `notifications_leads_activity`, `notifications_tasks_activity`, `notifications_tickets_activity`, `thridparty_stripe_customer_id`, `dashboard_access`, `welcome_email_sent`, `updated_at`, `created_at`) VALUES
(1, '2023-09-13 09:55:02', '2023-10-05 09:14:55', '', 1, 'superadmin', 'superadmin@gmail.com', '$2y$12$zYf1bNt4wfN/5FgMfdxHo.jaZIU4G6nkytzi7Eo.heoGq2cRUTcaW', 'Human', 'resource', '', '', '', '', '', 83157649, '', '', 'no', 'no', '', '', 'team', 'active', 1, '', 'default', '', '', '', '', '', '', 'english', 'yes', 'collapsed', 'collapsed', 'no', 'no', 'no', 'kanban', 'kanban', '', '', '', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', '', 'yes', 'no', '2023-10-05 05:14:55', '2023-09-13 05:55:02');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_accommodations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_accommodations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `address_line_1` tinytext NOT NULL,
  `address_line_2` tinytext DEFAULT NULL,
  `period_from` varchar(250) NOT NULL,
  `period_to` varchar(250) NOT NULL,
  `accommodation_type` int(11) NOT NULL,
  `annual_value` decimal(13,2) DEFAULT NULL,
  `furnished_type` int(11) DEFAULT NULL,
  `rent_value` decimal(13,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_advance_salaries`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_advance_salaries` (
  `advance_salary_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `month_year` varchar(255) NOT NULL,
  `advance_amount` varchar(255) NOT NULL,
  `one_time_deduct` varchar(50) NOT NULL,
  `monthly_installment` varchar(255) NOT NULL,
  `total_paid` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `status` int(11) DEFAULT NULL,
  `is_deducted_from_salary` int(11) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`advance_salary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_announcements`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_announcements` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `published_by` int(11) NOT NULL,
  `summary` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`announcement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_announcements`
		--
		INSERT INTO `xin_announcements` (`announcement_id`, `title`, `start_date`, `end_date`, `company_id`, `location_id`, `department_id`, `published_by`, `summary`, `description`, `is_active`, `is_notify`, `created_at`) VALUES
(2, 'Announcement 1', '02-10-2023', '24-10-2023', 10, 5, 14, 1, 'announcement annual', 'desc', 0, 0, '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_appendix8a_submission`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_appendix8a_submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `efiling_id` int(11) NOT NULL,
  `submission_key` varchar(256) DEFAULT NULL,
  `basis_year` year(4) NOT NULL,
  `no_of_records` int(11) DEFAULT NULL,
  `total_accommodation` decimal(13,2) DEFAULT NULL,
  `total_utilities_housekeeping` decimal(13,2) DEFAULT NULL,
  `total_hotel_accommodation` decimal(13,2) DEFAULT NULL,
  `total_other_benefits` decimal(13,2) DEFAULT NULL,
  `ap8a_file` varchar(128) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `submission_reference` varchar(256) DEFAULT NULL,
  `status_code` varchar(45) DEFAULT NULL,
  `submission_date` datetime DEFAULT NULL,
  `response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_appendix8b_submission`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_appendix8b_submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `efiling_id` int(11) NOT NULL,
  `submission_key` varchar(256) NOT NULL,
  `basis_year` year(4) NOT NULL,
  `no_of_records` int(11) NOT NULL,
  `total_gross_amount_eebr` decimal(13,2) DEFAULT NULL,
  `total_gross_amount_eris_sme` decimal(13,2) DEFAULT NULL,
  `total_gross_amount_eris_corp` decimal(13,2) DEFAULT NULL,
  `total_gross_amount_eris_startup` decimal(13,2) DEFAULT NULL,
  `ap8b_file` varchar(128) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `submission_reference` varchar(256) DEFAULT NULL,
  `status_code` varchar(45) DEFAULT NULL,
  `submission_date` datetime DEFAULT NULL,
  `response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_assets`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_assets` (
  `assets_id` int(11) NOT NULL AUTO_INCREMENT,
  `assets_category_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `company_asset_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `purchase_date` varchar(255) NOT NULL,
  `invoice_number` varchar(255) NOT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `serial_number` varchar(255) NOT NULL,
  `warranty_end_date` varchar(255) NOT NULL,
  `asset_note` text NOT NULL,
  `asset_image` varchar(255) NOT NULL,
  `is_working` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`assets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_assets_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_assets_categories` (
  `assets_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`assets_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_attendance_time`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_attendance_time` (
  `time_attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `attendance_date` varchar(255) NOT NULL,
  `clock_in` varchar(255) NOT NULL,
  `clock_in_ip_address` varchar(255) NOT NULL,
  `clock_out` varchar(255) NOT NULL,
  `clock_out_ip_address` varchar(255) NOT NULL,
  `clock_in_out` varchar(255) NOT NULL,
  `clock_in_latitude` varchar(150) NOT NULL,
  `clock_in_longitude` varchar(150) NOT NULL,
  `clock_out_latitude` varchar(150) NOT NULL,
  `clock_out_longitude` varchar(150) NOT NULL,
  `time_late` varchar(255) NOT NULL,
  `early_leaving` varchar(255) NOT NULL,
  `overtime` varchar(255) NOT NULL,
  `total_work` varchar(255) NOT NULL,
  `total_rest` varchar(255) NOT NULL,
  `attendance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`time_attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1333 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_attendance_time`
		--
		INSERT INTO `xin_attendance_time` (`time_attendance_id`, `employee_id`, `attendance_date`, `clock_in`, `clock_in_ip_address`, `clock_out`, `clock_out_ip_address`, `clock_in_out`, `clock_in_latitude`, `clock_in_longitude`, `clock_out_latitude`, `clock_out_longitude`, `time_late`, `early_leaving`, `overtime`, `total_work`, `total_rest`, `attendance_status`) VALUES
(1325, 4, '', ' 08:00:00', '', ' 12:00:00', '', 0, '', '', '', '', ' 08:00:00', ' 12:00:00', ' 12:00:00', '4:0', '', 'Present'),
(1326, 6, '', ' 00:00:00', '', ' 00:00:00', '', 0, '', '', '', '', ' 00:00:00', ' 00:00:00', ' 00:00:00', '0:0', '', 'Present'),
(1327, 7, '', ' 08:59:00', '', ' 18:00:00', '', 0, '', '', '', '', ' 08:59:00', ' 18:00:00', ' 18:00:00', '9:1', '', 'Present'),
(1328, 7, '', ' 08:00:00', '', ' 18:00:00', '', 0, '', '', '', '', ' 08:00:00', ' 18:00:00', ' 18:00:00', '10:0', '10:0', 'Present'),
(1329, 7, '', ' 08:00:00', '', ' 18:00:00', '', 0, '', '', '', '', ' 08:00:00', ' 18:00:00', ' 18:00:00', '10:0', '10:0', 'Present'),
(1330, 7, '', ' 09:00:00', '', ' 06:00:00', '', 0, '', '', '', '', ' 09:00:00', ' 06:00:00', ' 06:00:00', '3:0', '9:0', 'Present'),
(1331, 7, '', ' 10:00:00', '', ' 18:00:00', '', 0, '', '', '', '', ' 10:00:00', ' 18:00:00', ' 18:00:00', '8:0', '4:0', 'Present'),
(1332, 7, '05-10-2023', '05-10-2023 09:00:00', '', '05-10-2023 18:00:00', '', 0, '', '', '', '', '05-10-2023 09:00:00', '05-10-2023 18:00:00', '05-10-2023 18:00:00', '9:0', '', 'Present');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_attendance_time_request`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_attendance_time_request` (
  `time_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `request_date` varchar(255) NOT NULL,
  `request_date_request` varchar(255) NOT NULL,
  `request_clock_in` varchar(200) NOT NULL,
  `request_clock_out` varchar(200) NOT NULL,
  `total_hours` varchar(255) NOT NULL,
  `project_no` varchar(200) NOT NULL,
  `purchase_no` varchar(200) DEFAULT NULL,
  `task_id` int(11) NOT NULL,
  `request_reason` text NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`time_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_award_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_award_type` (
  `award_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `award_type` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`award_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_awards`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_awards` (
  `award_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `award_type_id` int(11) NOT NULL,
  `gift_item` varchar(200) NOT NULL,
  `cash_price` varchar(200) NOT NULL,
  `award_photo` varchar(255) NOT NULL,
  `award_month_year` varchar(200) NOT NULL,
  `award_information` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`award_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_chat_messages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_chat_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` varchar(40) NOT NULL DEFAULT '',
  `to_id` varchar(50) NOT NULL DEFAULT '',
  `message_frm` varchar(255) NOT NULL,
  `is_read` int(11) NOT NULL DEFAULT 0,
  `message_content` longtext NOT NULL,
  `message_date` varchar(255) DEFAULT NULL,
  `recd` tinyint(1) NOT NULL DEFAULT 0,
  `message_type` varchar(255) NOT NULL DEFAULT '',
  `department_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_chat_messages`
		--
		INSERT INTO `xin_chat_messages` (`message_id`, `from_id`, `to_id`, `message_frm`, `is_read`, `message_content`, `message_date`, `recd`, `message_type`, `department_id`, `location_id`) VALUES
(1, 1, 34, 34, 1, 'hiii', '2022-08-19 19:36:57', 0, '', 0, 0),
(2, 34, 1, 1, 1, 'hlw', '2022-08-19 19:37:22', 0, '', 0, 0),
(3, 1, 46, 46, 0, 'Hi', '2022-09-07 11:18:04', 0, '', 0, 0);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_claim_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_claim_type` (
  `claim_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`claim_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_clients`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `client_username` varchar(255) NOT NULL,
  `client_password` varchar(255) NOT NULL,
  `client_profile` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `is_changed` int(11) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_companies`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_companies` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `trading_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_no` varchar(255) NOT NULL,
  `government_tax` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `default_currency` varchar(200) DEFAULT NULL,
  `default_timezone` varchar(200) DEFAULT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_companies`
		--
		INSERT INTO `xin_companies` (`company_id`, `type_id`, `name`, `trading_name`, `username`, `password`, `registration_no`, `government_tax`, `email`, `logo`, `contact_number`, `website_url`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `is_active`, `default_currency`, `default_timezone`, `added_by`, `created_at`) VALUES
(1, 7, 'HRMS', '', 'Superadmin', '', '201628576W', '', 'superadmin@gmail.com', 'logo_1669291968.jpg', 6900000, 'superadmin.com', '8 Boon Lay Way #05-10 8@Tradehub 21', '', 'Singapore', '', 609964, 195, 0, 'SGD - S$', 'Asia/Singapore', 1, '24-11-2022'),
(10, 1, 'Mahan Manufacturing Pte Ltd', '', 'Mahan', 'admin123', '', '', 'mahan@gmail.com', 'logo_1695780670.jpg', 84635451, 'www.mahan.sg', '', '', 'Singapore', 'Singapore', 821171, 195, 0, 'SGD - S$', 'Asia/Singapore', 1, '27-09-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_documents`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_documents` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_type_id` int(11) NOT NULL,
  `license_name` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `expiry_date` varchar(255) NOT NULL,
  `license_number` varchar(255) NOT NULL,
  `license_notification` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `document` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_info`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_info` (
  `company_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) NOT NULL,
  `logo_second` varchar(255) NOT NULL,
  `sign_in_logo` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `website_url` mediumtext NOT NULL,
  `starting_year` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `company_contact` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`company_info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_company_info`
		--
		INSERT INTO `xin_company_info` (`company_info_id`, `logo`, `logo_second`, `sign_in_logo`, `favicon`, `website_url`, `starting_year`, `company_name`, `company_email`, `company_contact`, `contact_person`, `email`, `phone`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `updated_at`) VALUES
(1, 'logo_1686747348.jpg', 'logo2_1520609223.png', 'signin_logo_1686747362.jpg', 'favicon_1686747355.jpg', '', '', 'Mahan Manufacturing Ptd Ltd', '', '', 'Mahan', 'mahan@gmail.com', 1234566789, '', 'Demo', 'Singapore', 'Singapore', 348598, 195, '2017-05-20 12:05:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_policy`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_policy` (
  `policy_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`policy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_company_policy`
		--
		INSERT INTO `xin_company_policy` (`policy_id`, `company_id`, `title`, `description`, `attachment`, `added_by`, `created_at`) VALUES
(2, 10, 'New Policy', '&lt;p&gt;&lt;span xss=removed&gt;New Policy 111&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 'company_policy_1696210821.jpeg', 1, '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_company_type`
		--
		INSERT INTO `xin_company_type` (`type_id`, `name`, `created_at`) VALUES
(1, 'Corporation', ''),
(3, 'Partnership', ''),
(5, 'Limited Liability Company', ''),
(6, 'Sole Proprietor', '30-11-2022 01:01:54'),
(7, 'Private Limited Company', '30-11-2022 01:03:01');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_contract_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_contract_type` (
  `contract_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contract_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_contract_type`
		--
		INSERT INTO `xin_contract_type` (`contract_type_id`, `company_id`, `name`, `created_at`) VALUES
(1, 1, 'Full Time', '05-04-2018 06:10:32'),
(2, 0, '2 Year Short-Term', '07-04-2021 02:10:41'),
(4, 0, 'One Year Contract', '07-09-2022 10:17:31'),
(5, 0, 'Part Time', '15-02-2023 12:37:02'),
(9, 0, 'Internship', '02-10-2023 03:36:56');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_contribution_funds`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_contribution_funds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contribution` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_contribution_funds`
		--
		INSERT INTO `xin_contribution_funds` (`id`, `contribution`, `created_at`, `updated_at`) VALUES
(1, 'MBMF', '2021-02-09 23:24:34', ''),
(2, 'SINDA', '2021-02-09 23:24:34', ''),
(3, 'CDAC', '2021-02-09 23:24:34', ''),
(4, 'ECF', '2021-02-09 23:24:34', ''),
(5, 'SDL', '2021-02-09 23:24:34', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_contribution_payslip`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_contribution_payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `contribution_id` int(11) NOT NULL,
  `contribution_amount` decimal(6,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_contribution_payslip`
		--
		INSERT INTO `xin_contribution_payslip` (`id`, `payslip_id`, `contribution_id`, `contribution_amount`, `created_at`, `updated_at`) VALUES
(21, 1, 5, 11.25, '2023-10-01 21:51:37', ''),
(22, 2, 5, 11.25, '2023-10-02 23:46:56', ''),
(23, 3, 5, 11.25, '2023-10-04 23:33:23', ''),
(24, 4, 5, 11.25, '2023-10-04 23:33:55', ''),
(25, 5, 5, 2.00, '2023-10-04 23:33:55', ''),
(26, 6, 5, 11.25, '2023-10-05 03:48:19', ''),
(27, 7, 5, 2.50, '2023-10-05 03:48:19', ''),
(28, 8, 5, 11.25, '2023-10-05 03:49:18', ''),
(29, 9, 5, 2.50, '2023-10-05 03:49:18', ''),
(30, 10, 5, 11.25, '2023-10-05 04:21:17', ''),
(31, 11, 5, 2.50, '2023-10-05 04:21:17', ''),
(32, 12, 5, 11.25, '2023-10-05 04:21:35', ''),
(33, 13, 5, 2.50, '2023-10-05 04:21:35', ''),
(34, 14, 5, 11.25, '2023-10-05 04:21:37', ''),
(35, 15, 5, 2.50, '2023-10-05 04:21:37', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_contribution_rates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_contribution_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contribution_id` int(11) NOT NULL,
  `date_effect` date DEFAULT NULL,
  `min_salary` decimal(10,2) DEFAULT NULL,
  `max_salary` decimal(10,2) DEFAULT NULL,
  `contribution_amount` decimal(6,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_contribution_id_idx` (`contribution_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_contribution_rates`
		--
		INSERT INTO `xin_contribution_rates` (`id`, `contribution_id`, `date_effect`, `min_salary`, `max_salary`, `contribution_amount`, `created_at`, `updated_at`) VALUES
(1, 1, '2016-06-01', '', 1000.00, 3.00, '2021-02-09 23:24:34', ''),
(2, 1, '2016-06-01', 1000.00, 2000.00, 4.50, '2021-02-09 23:24:34', ''),
(3, 1, '2016-06-01', 2000.00, 3000.00, 6.50, '2021-02-09 23:24:34', ''),
(4, 1, '2016-06-01', 3000.00, 4000.00, 15.00, '2021-02-09 23:24:34', ''),
(5, 1, '2016-06-01', 4000.00, 6000.00, 19.50, '2021-02-09 23:24:34', ''),
(6, 1, '2016-06-01', 6000.00, 8000.00, 22.00, '2021-02-09 23:24:34', ''),
(7, 1, '2016-06-01', 8000.00, 10000.00, 24.00, '2021-02-09 23:24:34', ''),
(8, 1, '2016-06-01', 10000.00, '', 26.00, '2021-02-09 23:24:34', ''),
(9, 2, '2015-01-01', '', 1000.00, 1.00, '2021-02-09 23:24:34', ''),
(10, 2, '2015-01-01', 1000.00, 1500.00, 3.00, '2021-02-09 23:24:34', ''),
(11, 2, '2015-01-01', 1500.00, 2500.00, 5.00, '2021-02-09 23:24:34', ''),
(12, 2, '2015-01-01', 2500.00, 4500.00, 7.00, '2021-02-09 23:24:34', ''),
(13, 2, '2015-01-01', 4500.00, 7500.00, 9.00, '2021-02-09 23:24:34', ''),
(14, 2, '2015-01-01', 7500.00, 10000.00, 12.00, '2021-02-09 23:24:34', ''),
(15, 2, '2015-01-01', 10000.00, 15000.00, 18.00, '2021-02-09 23:24:34', ''),
(16, 2, '2015-01-01', 15000.00, '', 30.00, '2021-02-09 23:24:34', ''),
(17, 3, '2015-01-01', '', 2000.00, 0.50, '2021-02-09 23:24:34', ''),
(18, 3, '2015-01-01', 2000.00, 3500.00, 1.00, '2021-02-09 23:24:34', ''),
(19, 3, '2015-01-01', 3500.00, 5000.00, 1.50, '2021-02-09 23:24:34', ''),
(20, 3, '2015-01-01', 5000.00, 7500.00, 2.00, '2021-02-09 23:24:34', ''),
(21, 3, '2015-01-01', 7500.00, '', 3.00, '2021-02-09 23:24:34', ''),
(22, 4, '2015-01-01', '', 1000.00, 2.00, '2021-02-09 23:24:34', ''),
(23, 4, '2015-01-01', 1000.00, 1500.00, 4.00, '2021-02-09 23:24:34', ''),
(24, 4, '2015-01-01', 1500.00, 2500.00, 6.00, '2021-02-09 23:24:34', ''),
(25, 4, '2015-01-01', 2500.00, 4000.00, 9.00, '2021-02-09 23:24:34', ''),
(26, 4, '2015-01-01', 4000.00, 7000.00, 12.00, '2021-02-09 23:24:34', ''),
(27, 4, '2015-01-01', 7000.00, 10000.00, 16.00, '2021-02-09 23:24:34', ''),
(28, 4, '2015-01-01', 10000.00, '', 20.00, '2021-02-09 23:24:34', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_countries`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(255) NOT NULL,
  `country_name` varchar(255) NOT NULL,
  `country_flag` varchar(255) NOT NULL,
  `iras_nationality_code` int(11) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_countries`
		--
		INSERT INTO `xin_countries` (`country_id`, `country_code`, `country_name`, `country_flag`, `iras_nationality_code`) VALUES
(1, +93, 'Afghanistan', 'fla??  ?V     ^', ''),
(3, 'DZ', 'Algeria', '', ''),
(4, 'DS', 'American Samoa', '', ''),
(5, 'AD', 'Andorra', '', ''),
(6, 'AO', 'Angola', '', ''),
(7, 'AI', 'Anguilla', '', ''),
(8, 'AQ', 'Antarctica', '', ''),
(9, 'AG', 'Antigua and Barbuda', '', ''),
(10, 'AR', 'Argentina', '', ''),
(11, 'AM', 'Armenia', '', ''),
(12, 'AW', 'Aruba', '', ''),
(13, 'AU', 'Australia', '', ''),
(14, 'AT', 'Austria', '', ''),
(15, 'AZ', 'Azerbaijan', '', ''),
(16, 'BS', 'Bahamas', '', ''),
(17, 'BH', 'Bahrain', '', ''),
(18, 'BD', 'Bangladesh', '', ''),
(19, 'BB', 'Barbados', '', ''),
(20, 'BY', 'Belarus', '', ''),
(21, 'BE', 'Belgium', '', ''),
(22, 'BZ', 'Belize', '', ''),
(23, 'BJ', 'Benin', '', ''),
(24, 'BM', 'Bermuda', '', ''),
(25, 'BT', 'Bhutan', '', ''),
(26, 'BO', 'Bolivia', '', ''),
(27, 'BA', 'Bosnia and Herzegovina', '', ''),
(28, 'BW', 'Botswana', '', ''),
(29, 'BV', 'Bouvet Island', '', ''),
(30, 'BR', 'Brazil', '', ''),
(31, 'IO', 'British Indian Ocean Territory', '', ''),
(32, 'BN', 'Brunei Darussalam', '', ''),
(33, 'BG', 'Bulgaria', '', ''),
(34, 'BF', 'Burkina Faso', '', ''),
(35, 'BI', 'Burundi', '', ''),
(36, 'KH', 'Cambodia', '', ''),
(37, 'CM', 'Cameroon', '', ''),
(38, 'CA', 'Canada', '', ''),
(39, 'CV', 'Cape Verde', '', ''),
(40, 'KY', 'Cayman Islands', '', ''),
(41, 'CF', 'Central African Republic', '', ''),
(42, 'TD', 'Chad', '', ''),
(43, 'CL', 'Chile', '', ''),
(44, 'CN', 'China', '', ''),
(45, 'CX', 'Christmas Island', '', ''),
(46, 'CC', 'Cocos (Keeling) Islands', '', ''),
(47, 'CO', 'Colombia', '', ''),
(48, 'KM', 'Comoros', '', ''),
(49, 'CG', 'Congo', '', ''),
(50, 'CK', 'Cook Islands', '', ''),
(51, 'CR', 'Costa Rica', '', ''),
(52, 'HR', 'Croatia (Hrvatska)', '', ''),
(53, 'CU', 'Cuba', '', ''),
(54, 'CY', 'Cyprus', '', ''),
(55, 'CZ', 'Czech Republic', '', ''),
(56, 'DK', 'Denmark', '', ''),
(57, 'DJ', 'Djibouti', '', ''),
(58, 'DM', 'Dominica', '', ''),
(59, 'DO', 'Dominican Republic', '', ''),
(60, 'TP', 'East Timor', '', ''),
(61, 'EC', 'Ecuador', '', ''),
(62, 'EG', 'Egypt', '', ''),
(63, 'SV', 'El Salvador', '', ''),
(64, 'GQ', 'Equatorial Guinea', '', ''),
(65, 'ER', 'Eritrea', '', ''),
(66, 'EE', 'Estonia', '', ''),
(67, 'ET', 'Ethiopia', '', ''),
(68, 'FK', 'Falkland Islands (Malvinas)', '', ''),
(69, 'FO', 'Faroe Islands', '', ''),
(70, 'FJ', 'Fiji', '', ''),
(71, 'FI', 'Finland', '', ''),
(72, 'FR', 'France', '', ''),
(73, 'FX', 'France, Metropolitan', '', ''),
(74, 'GF', 'French Guiana', '', ''),
(75, 'PF', 'French Polynesia', '', ''),
(76, 'TF', 'French Southern Territories', '', ''),
(77, 'GA', 'Gabon', '', ''),
(78, 'GM', 'Gambia', '', ''),
(79, 'GE', 'Georgia', '', ''),
(80, 'DE', 'Germany', '', ''),
(81, 'GH', 'Ghana', '', ''),
(82, 'GI', 'Gibraltar', '', ''),
(83, 'GK', 'Guernsey', '', ''),
(84, 'GR', 'Greece', '', ''),
(85, 'GL', 'Greenland', '', ''),
(86, 'GD', 'Grenada', '', ''),
(87, 'GP', 'Guadeloupe', '', ''),
(88, 'GU', 'Guam', '', ''),
(89, 'GT', 'Guatemala', '', ''),
(90, 'GN', 'Guinea', '', ''),
(91, 'GW', 'Guinea-Bissau', '', ''),
(92, 'GY', 'Guyana', '', ''),
(93, 'HT', 'Haiti', '', ''),
(94, 'HM', 'Heard and Mc Donald Islands', '', ''),
(95, 'HN', 'Honduras', '', ''),
(96, 'HK', 'Hong Kong', '', ''),
(97, 'HU', 'Hungary', '', ''),
(98, 'IS', 'Iceland', '', ''),
(99, 'IN', 'India', '', 354),
(100, 'IM', 'Isle of Man', '', ''),
(101, 'ID', 'Indonesia', '', ''),
(102, 'IR', 'Iran (Islamic Republic of)', '', ''),
(103, 'IQ', 'Iraq', '', ''),
(104, 'IE', 'Ireland', '', ''),
(105, 'IL', 'Israel', '', ''),
(106, 'IT', 'Italy', '', ''),
(107, 'CI', 'Ivory Coast', '', ''),
(108, 'JE', 'Jersey', '', ''),
(109, 'JM', 'Jamaica', '', ''),
(110, 'JP', 'Japan', '', ''),
(111, 'JO', 'Jordan', '', ''),
(112, 'KZ', 'Kazakhstan', '', ''),
(113, 'KE', 'Kenya', '', ''),
(114, 'KI', 'Kiribati', '', ''),
(115, 'KP', 'Korea, Democratic People''s Republic of', '', ''),
(116, 'KR', 'Korea, Republic of', '', ''),
(117, 'XK', 'Kosovo', '', ''),
(118, 'KW', 'Kuwait', '', ''),
(119, 'KG', 'Kyrgyzstan', '', ''),
(120, 'LA', 'Lao People''s Democratic Republic', '', ''),
(121, 'LV', 'Latvia', '', ''),
(122, 'LB', 'Lebanon', '', ''),
(123, 'LS', 'Lesotho', '', ''),
(124, 'LR', 'Liberia', '', ''),
(125, 'LY', 'Libyan Arab Jamahiriya', '', ''),
(126, 'LI', 'Liechtenstein', '', ''),
(127, 'LT', 'Lithuania', '', ''),
(128, 'LU', 'Luxembourg', '', ''),
(129, 'MO', 'Macau', '', ''),
(130, 'MK', 'Macedonia', '', ''),
(131, 'MG', 'Madagascar', '', ''),
(132, 'MW', 'Malawi', '', ''),
(133, 'MY', 'Malaysia', '', ''),
(134, 'MV', 'Maldives', '', ''),
(135, 'ML', 'Mali', '', ''),
(136, 'MT', 'Malta', '', ''),
(137, 'MH', 'Marshall Islands', '', ''),
(138, 'MQ', 'Martinique', '', ''),
(139, 'MR', 'Mauritania', '', ''),
(140, 'MU', 'Mauritius', '', ''),
(141, 'TY', 'Mayotte', '', ''),
(142, 'MX', 'Mexico', '', ''),
(143, 'FM', 'Micronesia, Federated States of', '', ''),
(144, 'MD', 'Moldova, Republic of', '', ''),
(145, 'MC', 'Monaco', '', ''),
(146, 'MN', 'Mongolia', '', ''),
(147, 'ME', 'Montenegro', '', ''),
(148, 'MS', 'Montserrat', '', ''),
(149, 'MA', 'Morocco', '', ''),
(150, 'MZ', 'Mozambique', '', ''),
(151, 'MM', 'Myanmar', '', ''),
(152, 'NA', 'Namibia', '', ''),
(153, 'NR', 'Nauru', '', ''),
(154, 'NP', 'Nepal', '', ''),
(155, 'NL', 'Netherlands', '', ''),
(156, 'AN', 'Netherlands Antilles', '', ''),
(157, 'NC', 'New Caledonia', '', ''),
(158, 'NZ', 'New Zealand', '', ''),
(159, 'NI', 'Nicaragua', '', ''),
(160, 'NE', 'Niger', '', ''),
(161, 'NG', 'Nigeria', '', ''),
(162, 'NU', 'Niue', '', ''),
(163, 'NF', 'Norfolk Island', '', ''),
(164, 'MP', 'Northern Mariana Islands', '', ''),
(165, 'NO', 'Norway', '', ''),
(166, 'OM', 'Oman', '', ''),
(167, 'PK', 'Pakistan', '', ''),
(168, 'PW', 'Palau', '', ''),
(169, 'PS', 'Palestine', '', ''),
(170, 'PA', 'Panama', '', ''),
(171, 'PG', 'Papua New Guinea', '', ''),
(172, 'PY', 'Paraguay', '', ''),
(173, 'PE', 'Peru', '', ''),
(174, 'PH', 'Philippines', '', ''),
(175, 'PN', 'Pitcairn', '', ''),
(176, 'PL', 'Poland', '', ''),
(177, 'PT', 'Portugal', '', ''),
(178, 'PR', 'Puerto Rico', '', ''),
(179, 'QA', 'Qatar', '', ''),
(180, 'RE', 'Reunion', '', ''),
(181, 'RO', 'Romania', '', ''),
(182, 'RU', 'Russian Federation', '', ''),
(183, 'RW', 'Rwanda', '', ''),
(184, 'KN', 'Saint Kitts and Nevis', '', ''),
(185, 'LC', 'Saint Lucia', '', ''),
(186, 'VC', 'Saint Vincent and the Grenadines', '', ''),
(187, 'WS', 'Samoa', '', ''),
(188, 'SM', 'San Marino', '', ''),
(189, 'ST', 'Sao Tome and Principe', '', ''),
(190, 'SA', 'Saudi Arabia', '', ''),
(191, 'SN', 'Senegal', '', ''),
(192, 'RS', 'Serbia', '', ''),
(193, 'SC', 'Seychelles', '', ''),
(194, 'SL', 'Sierra Leone', '', ''),
(195, 'SG', 'Singapore', '', 301),
(196, 'SK', 'Slovakia', '', ''),
(197, 'SI', 'Slovenia', '', ''),
(198, 'SB', 'Solomon Islands', '', ''),
(199, 'SO', 'Somalia', '', ''),
(200, 'ZA', 'South Africa', '', ''),
(201, 'GS', 'South Georgia South Sandwich Islands', '', ''),
(202, 'ES', 'Spain', '', ''),
(203, 'LK', 'Sri Lanka', '', ''),
(204, 'SH', 'St. Helena', '', ''),
(205, 'PM', 'St. Pierre and Miquelon', '', ''),
(206, 'SD', 'Sudan', '', ''),
(207, 'SR', 'Suriname', '', ''),
(208, 'SJ', 'Svalbard and Jan Mayen Islands', '', ''),
(209, 'SZ', 'Swaziland', '', ''),
(210, 'SE', 'Sweden', '', ''),
(211, 'CH', 'Switzerland', '', ''),
(212, 'SY', 'Syrian Arab Republic', '', ''),
(213, 'TW', 'Taiwan', '', ''),
(214, 'TJ', 'Tajikistan', '', ''),
(215, 'TZ', 'Tanzania, United Republic of', '', ''),
(216, 'TH', 'Thailand', '', ''),
(217, 'TG', 'Togo', '', ''),
(218, 'TK', 'Tokelau', '', ''),
(219, 'TO', 'Tonga', '', ''),
(220, 'TT', 'Trinidad and Tobago', '', ''),
(221, 'TN', 'Tunisia', '', ''),
(222, 'TR', 'Turkey', '', ''),
(223, 'TM', 'Turkmenistan', '', ''),
(224, 'TC', 'Turks and Caicos Islands', '', ''),
(225, 'TV', 'Tuvalu', '', ''),
(226, 'UG', 'Uganda', '', ''),
(227, 'UA', 'Ukraine', '', ''),
(228, 'AE', 'United Arab Emirates', '', ''),
(229, 'GB', 'United Kingdom', '', ''),
(230, 'US', 'United States', '', ''),
(231, 'UM', 'United States minor outlying islands', '', ''),
(232, 'UY', 'Uruguay', '', ''),
(233, 'UZ', 'Uzbekistan', '', ''),
(234, 'VU', 'Vanuatu', '', ''),
(235, 'VA', 'Vatican City State', '', ''),
(236, 'VE', 'Venezuela', '', ''),
(237, 'VN', 'Vietnam', '', ''),
(238, 'VG', 'Virgin Islands (British)', '', ''),
(239, 'VI', 'Virgin Islands (U.S.)', '', ''),
(240, 'WF', 'Wallis and Futuna Islands', '', ''),
(241, 'EH', 'Western Sahara', '', ''),
(242, 'YE', 'Yemen', '', ''),
(243, 'ZR', 'Zaire', '', ''),
(244, 'ZM', 'Zambia', '', ''),
(245, 'ZW', 'Zimbabwe', '', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_cpf_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_cpf_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_name` varchar(45) DEFAULT NULL,
  `option_value` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_cpf_options`
		--
		INSERT INTO `xin_cpf_options` (`id`, `option_name`, `option_value`, `created_at`, `updated_at`) VALUES
(1, 'ordinary_wage_cap', 6000, '2021-02-10 04:24:34', ''),
(2, 'emp_upto_age', 55, '2021-02-10 04:24:34', ''),
(3, 'emp_above_age', 65, '2021-02-10 04:24:34', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_cpf_payslip`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_cpf_payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `month_year` varchar(250) NOT NULL,
  `ow_paid` decimal(13,4) NOT NULL,
  `ow_cpf` decimal(13,4) NOT NULL,
  `ow_cpf_employer` decimal(13,4) NOT NULL,
  `ow_cpf_employee` decimal(13,4) DEFAULT NULL,
  `aw_paid` decimal(13,4) DEFAULT NULL,
  `aw_cpf` decimal(13,4) DEFAULT NULL,
  `aw_cpf_employer` decimal(13,4) DEFAULT NULL,
  `aw_cpf_employee` decimal(13,4) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_cpf_payslip`
		--
		INSERT INTO `xin_cpf_payslip` (`id`, `payslip_id`, `month_year`, `ow_paid`, `ow_cpf`, `ow_cpf_employer`, `ow_cpf_employee`, `aw_paid`, `aw_cpf`, `aw_cpf_employer`, `aw_cpf_employee`, `created_at`, `updated_at`) VALUES
(12, 1, '01-10-2023', 51000.0000, 6000.0000, 1020.0000, 1200.0000, 0.0000, 0.0000, 0.0000, 0.0000, '2023-10-01 21:51:37', ''),
(13, 2, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-02 23:46:56', ''),
(14, 3, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-04 23:33:23', ''),
(15, 4, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-04 23:33:55', ''),
(16, 6, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-05 03:48:19', ''),
(17, 8, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-05 03:49:18', ''),
(18, 10, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-05 04:21:17', ''),
(19, 12, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-05 04:21:35', ''),
(20, 14, '01-10-2023', 51100.0000, 6000.0000, 1020.0000, 1200.0000, 100.0000, 100.0000, 17.0000, 20.0000, '2023-10-05 04:21:37', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_cpf_percentage`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_cpf_percentage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `immigration_status` int(11) NOT NULL,
  `immigration_status_year` int(11) DEFAULT NULL,
  `employee_age_from` int(11) DEFAULT NULL,
  `employee_age_to` int(11) DEFAULT NULL,
  `contribution_employer` float NOT NULL,
  `contribution_employee` float NOT NULL,
  `total_cpf` float NOT NULL,
  `effective_from` date NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_cpf_percentage`
		--
		INSERT INTO `xin_cpf_percentage` (`id`, `immigration_status`, `immigration_status_year`, `employee_age_from`, `employee_age_to`, `contribution_employer`, `contribution_employee`, `total_cpf`, `effective_from`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '', '', 55, 17, 20, 37, '2016-01-01', 1, '2021-02-10 04:24:34', '2020-09-03 15:27:05'),
(2, 1, '', 55, 60, 14.5, 15, 29.5, '2016-01-01', 1, '2021-02-10 04:24:34', '2023-02-15 20:16:27'),
(3, 1, '', 60, 65, 11, 9.5, 20.5, '2016-01-01', 1, '2021-02-10 04:24:34', '2023-02-15 20:17:43'),
(4, 1, '', 65, 70, 8.5, 7, 15.5, '2016-01-01', 1, '2021-02-10 04:24:34', '2023-02-15 20:19:26'),
(5, 2, 1, '', 55, 4, 5, 9, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(6, 2, 1, 55, 60, 4, 5, 9, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(7, 2, 1, 60, 65, 3.5, 5, 8.5, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(8, 2, 1, 65, '', 3.5, 5, 8.5, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(9, 2, 2, '', 55, 9, 15, 24, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(10, 2, 2, 55, 60, 6, 12.5, 18.5, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(11, 2, 2, 60, 65, 3.5, 7.5, 11, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(12, 2, 2, 65, '', 3.5, 5, 8.5, '2016-01-01', 1, '2021-02-10 04:24:34', ''),
(13, 1, '', 70, '', 7.5, 5, 12.5, '2016-01-01', 1, '2021-02-10 04:24:34', '2023-02-15 19:07:35');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_cpf_submission`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_cpf_submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `csn` varchar(45) NOT NULL,
  `month_year` date NOT NULL,
  `no_employees` int(11) NOT NULL,
  `no_records` int(11) NOT NULL,
  `cpf_contribution_amount` decimal(10,2) NOT NULL,
  `other_contribution` decimal(10,2) NOT NULL,
  `total_contribution_amount` decimal(13,2) NOT NULL,
  `cpf_file` varchar(128) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_currencies`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_currencies` (
  `currency_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_currencies`
		--
		INSERT INTO `xin_currencies` (`currency_id`, `company_id`, `name`, `code`, `symbol`) VALUES
(1, 1, 'Singapore Dollars', 'SGD', 'S$'),
(2, 0, 'Malaysia Ringgit', 'MYR', 'RM');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_currency_converter`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_currency_converter` (
  `currency_converter_id` int(11) NOT NULL AUTO_INCREMENT,
  `usd_currency` varchar(11) NOT NULL DEFAULT '1',
  `to_currency_title` varchar(200) NOT NULL,
  `to_currency_rate` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`currency_converter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_currency_converter`
		--
		INSERT INTO `xin_currency_converter` (`currency_converter_id`, `usd_currency`, `to_currency_title`, `to_currency_rate`, `created_at`) VALUES
(1, 1, 'MYR', 4.11, '17-08-2018 03:29:58');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_database_backup`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_database_backup` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_file` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_departments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_departments` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(200) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_departments`
		--
		INSERT INTO `xin_departments` (`department_id`, `department_name`, `company_id`, `location_id`, `employee_id`, `added_by`, `created_at`, `status`) VALUES
(1, 'HR', 10, 1, 0, 1, '2022-11-25 21:54:03', 1),
(2, 'Operation', 10, 1, 0, 1, '2022-11-25 22:08:15', 1),
(3, 'Account', 1, 1, 0, 1, '2022-11-29 13:11:01', 1),
(5, 'Director', 1, 1, 0, 1, '2022-11-30 12:36:21', 1),
(15, 'abc', 10, 1, 0, 1, '2023-10-06 01:39:14', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_designations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_designations` (
  `designation_id` int(11) NOT NULL AUTO_INCREMENT,
  `top_designation_id` int(11) NOT NULL DEFAULT 0,
  `department_id` int(11) NOT NULL,
  `sub_department_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `designation_name` varchar(200) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`designation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_designations`
		--
		INSERT INTO `xin_designations` (`designation_id`, `top_designation_id`, `department_id`, `sub_department_id`, `company_id`, `designation_name`, `added_by`, `created_at`, `status`) VALUES
(1, 0, 1, 4, 1, 'HR Executive', 1, '29-11-2022', 1),
(2, 0, 3, 5, 1, 'Account Executive', 1, '29-11-2022', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_document_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_document_type` (
  `document_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`document_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_document_type`
		--
		INSERT INTO `xin_document_type` (`document_type_id`, `company_id`, `document_type`, `created_at`) VALUES
(1, 1, 'Driving License', '09-05-2018 12:34:55'),
(2, 0, 'Work Permit', '07-04-2021 02:10:58'),
(3, 0, 'S Pass', '07-04-2021 02:11:03'),
(4, 0, 'NRIC', '29-11-2022 01:33:20'),
(5, 0, 'E Pass', '29-11-2022 01:33:29'),
(6, 0, 'Long Term Visit Pass', '29-11-2022 01:33:43'),
(7, 0, 'Passport', '09-02-2023 12:42:02');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_efiling_appendix8a`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_efiling_appendix8a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ap8a_key` varchar(256) NOT NULL,
  `submission_key` varchar(256) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `ap8a_year` year(4) NOT NULL,
  `accommodation` decimal(13,2) DEFAULT NULL,
  `utilities_housekeeping` decimal(13,2) DEFAULT NULL,
  `hotel_accommodation` decimal(13,2) DEFAULT NULL,
  `other_benefits` decimal(13,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_efiling_appendix8b`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_efiling_appendix8b` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ap8b_key` varchar(256) NOT NULL,
  `submission_key` varchar(256) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `ap8b_year` year(4) NOT NULL,
  `gross_amount_eebr` decimal(13,2) DEFAULT NULL,
  `gross_amount_eris_sme` decimal(13,2) DEFAULT NULL,
  `gross_amount_eris_corp` decimal(13,2) DEFAULT NULL,
  `gross_amount_eris_startup` decimal(13,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_efiling_details`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_efiling_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `csn` varchar(45) NOT NULL,
  `organisation_id_type` varchar(45) NOT NULL,
  `organisation_id_no` varchar(45) NOT NULL,
  `authorised_name` varchar(45) NOT NULL,
  `authorised_designation` varchar(45) NOT NULL,
  `authorised_id_type` int(11) DEFAULT NULL,
  `authorised_id_no` varchar(45) DEFAULT NULL,
  `authorised_email` varchar(45) DEFAULT NULL,
  `authorised_phone` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_efiling_details`
		--
		INSERT INTO `xin_efiling_details` (`id`, `company_id`, `csn`, `organisation_id_type`, `organisation_id_no`, `authorised_name`, `authorised_designation`, `authorised_id_type`, `authorised_id_no`, `authorised_email`, `authorised_phone`, `created_at`, `updated_at`) VALUES
(1, 1, '234567891BPTE01', 'U', 'T16ZZ0100B', 'Andrew', 'Accountant', 1, 'S8947663A', 'andrew@xyz.com', 61234567, '2021-02-09 23:24:34', '2020-08-04 20:53:17');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_efiling_ir8a`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_efiling_ir8a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ir8a_key` varchar(128) NOT NULL,
  `submission_key` varchar(256) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `ir8a_year` year(4) NOT NULL,
  `gross_salary` decimal(13,2) NOT NULL,
  `bonus` decimal(13,2) DEFAULT NULL,
  `director_fee` decimal(13,2) DEFAULT NULL,
  `allowance_transport` decimal(13,2) DEFAULT NULL,
  `allowance_entertainment` decimal(13,2) DEFAULT NULL,
  `allowance_other` decimal(13,2) DEFAULT NULL,
  `gross_commission` decimal(13,2) DEFAULT NULL,
  `pension` decimal(13,2) DEFAULT NULL,
  `gratuity` decimal(13,2) DEFAULT NULL,
  `notice_pay` decimal(13,2) DEFAULT NULL,
  `ex_gratia_payment` decimal(13,2) DEFAULT NULL,
  `other_lump_sum` decimal(13,2) DEFAULT NULL,
  `comp_loss_office` decimal(13,2) DEFAULT NULL,
  `approval_iras` tinyint(4) DEFAULT NULL,
  `date_of_approval` date DEFAULT NULL,
  `reason_for_payment` tinytext DEFAULT NULL,
  `length_of_service` varchar(128) DEFAULT NULL,
  `basis_of_payment` mediumtext DEFAULT NULL,
  `retirement_benefits_fund_name` varchar(128) DEFAULT NULL,
  `amount_upto_1992` decimal(13,2) DEFAULT NULL,
  `amount_from_1993` decimal(13,2) DEFAULT NULL,
  `overseas_provident_fund` varchar(128) DEFAULT NULL,
  `full_contribution_amount` decimal(13,2) DEFAULT NULL,
  `contriubution_mandatory` tinyint(4) DEFAULT NULL,
  `contriubtion_claimed` tinyint(4) DEFAULT NULL,
  `excess_cpf_contribution_ir8s` decimal(13,2) DEFAULT NULL,
  `stock_gains_ap8b` decimal(13,2) DEFAULT NULL,
  `benefits_in_kind_ap8a` decimal(13,2) DEFAULT NULL,
  `total_d1_to_d9` decimal(13,2) DEFAULT NULL,
  `remission_amount` decimal(13,2) DEFAULT NULL,
  `overseas_posting` varchar(128) DEFAULT NULL,
  `exempt_income` decimal(13,2) DEFAULT NULL,
  `tax_borne_by_employer` tinyint(4) DEFAULT NULL,
  `partial_tax_amount` decimal(13,2) DEFAULT NULL,
  `fixed_tax_amount` decimal(13,2) DEFAULT NULL,
  `cpf_employee_deduction` decimal(13,2) DEFAULT NULL,
  `donation_funds` decimal(13,2) DEFAULT NULL,
  `mbmf_funds` decimal(13,2) DEFAULT NULL,
  `life_insurance` decimal(13,2) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_email_configuration`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_email_configuration` (
  `email_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_type` enum('phpmail','smtp','codeigniter') NOT NULL,
  `smtp_host` varchar(64) NOT NULL,
  `smtp_username` varchar(64) NOT NULL,
  `smtp_password` varchar(64) NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `smtp_secure` enum('tls','ssl') NOT NULL,
  PRIMARY KEY (`email_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

		--
		-- Dumping data for table `xin_email_configuration`
		--
		INSERT INTO `xin_email_configuration` (`email_config_id`, `email_type`, `smtp_host`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_secure`) VALUES
(1, 'codeigniter', 'smtp.gmail.com', 'demo@gmail.com', 123456, 587, 'tls');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_email_template`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_email_template` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_email_template`
		--
		INSERT INTO `xin_email_template` (`template_id`, `template_code`, `name`, `subject`, `message`, `status`) VALUES
(2, 'code1', 'Forgot Password', 'Forgot Password', '&lt;p&gt;There was recently a request for password for your {var site_name} account.&lt;/p&gt;&lt;p&gt;If this was a mistake, just ignore this email and nothing will happen.&lt;br&gt;&lt;/p&gt;&lt;p&gt;To reset your password, visit the following link &lt;a href=\&quot;\\\\\&quot; admin=\&quot;\&quot; auth=\&quot;\&quot; password=\&quot;\&quot; change=\&quot;true&amp;email={var\&quot; title=\&quot;\\\\\&quot;&gt;&lt;a href=\&quot;{var site_url}admin/auth/reset_password/?change=true&amp;email={var email}\&quot; title=\&quot;reset_password\&quot;&gt;Reset Password&lt;/a&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; admin=\&quot;\\\\\&quot; auth=\&quot;\\\\\&quot; title=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Thank you,&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(3, 'code2', 'New Project', 'New Project', '&lt;p&gt;Dear {var name},&lt;/p&gt;&lt;p&gt;New project has been assigned to you.&lt;/p&gt;&lt;p&gt;Project Name: {var project_name}&lt;/p&gt;&lt;p&gt;Project Start Date:&amp;nbsp;&lt;span 1rem;\\\&quot;=\&quot;\&quot;&gt;{var project_start_date}&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span 1rem;\\\&quot;=\&quot;\&quot;&gt;Thank you,&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(5, 'code3', 'Leave Request ', 'A Leave Request from you', '&lt;p&gt;Dear Admin,&lt;/p&gt;&lt;p&gt;{var employee_name} wants a leave from you.&lt;/p&gt;&lt;p&gt;You can view this leave request by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;br&gt;&lt;br&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(6, 'code4', 'Leave Approve', 'Your leave request has been approved', '&lt;p&gt;Your leave request has been approved&lt;/p&gt;&lt;p&gt;&lt;span xss=removed&gt;Congratulations! Your leave request from&lt;/span&gt;&lt;font color=\&quot;\\\\\&quot; face=\&quot;\\\\\&quot; arial,=\&quot;\&quot; verdana,=\&quot;\&quot; trebuchet=\&quot;\&quot;&gt; &lt;/font&gt;{var leave_start_date} to {var leave_end_date} has been approved by your company management.&lt;/p&gt;&lt;p&gt;Check here&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(7, 'code5', 'Leave Reject', 'Your leave request has been Rejected', '&lt;p&gt;Your leave request has been Rejected&lt;/p&gt;&lt;p&gt;Unfortunately ! Your leave request from {var leave_start_date} to {var leave_end_date} has been Rejected by your company management.&lt;/p&gt;&lt;p&gt;Check here&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(8, 'code6', 'Welcome Email ', 'Welcome Email ', '&lt;p&gt;Hello {var employee_name},&lt;/p&gt;&lt;p&gt;Welcome to {var site_name} .Thanks for joining {var site_name}. We listed your sign in details below, make sure you keep them safe.&lt;/p&gt;&lt;p&gt;Your Username: {var username}&lt;/p&gt;&lt;p&gt;Your Employee ID: {var employee_id}&lt;br&gt;Your Email Address: {var email}&lt;br&gt;Your Password: {var password}&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; hr=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; admin=\&quot;\\\\\&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn\\\&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;https://zyhconstruction.com/login&lt;/p&gt;&lt;p&gt;Have fun!&lt;/p&gt;&lt;p&gt;The {var site_name} Team.&lt;/p&gt;', 1),
(9, 'code7', 'Transfer', 'New Transfer', '&lt;p&gt;Hello {var employee_name},&lt;/p&gt;&lt;p&gt;You have been transfered to another department and location.&lt;/p&gt;&lt;p&gt;You can view the transfer details by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(10, 'code8', 'Award', 'Award Received', '&lt;p&gt;Hello {var employee_name},&lt;/p&gt;&lt;p&gt;You have been awarded {var award_name}.&lt;/p&gt;&lt;p&gt;You can view this award by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;&lt;span xss=removed&gt;{var site_url}admin/&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(14, 'code9', 'New Task', 'Task assigned', '&lt;p&gt;Dear Employee,&lt;/p&gt;&lt;p&gt;A new task &lt;span xss=\&quot;\\\\\&quot;&gt;{var task_name}&lt;/span&gt; has been assigned to you by &lt;span xss=\&quot;\\\\\&quot;&gt;{var task_assigned_by}&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;You can view this task by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;/p&gt;&lt;p&gt;Regards,&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(15, 'code10', 'New Inquiry', 'New Inquiry [#{var ticket_code}]', '&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;&lt;span xss=\&quot;removed\&quot;&gt;Dear Admin,&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;&lt;span xss=\&quot;removed\&quot;&gt;Your received a new inquiry.&lt;/span&gt;&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;&lt;span xss=\&quot;removed\&quot;&gt;Inquiry Code: #{var ticket_code}&lt;/span&gt;&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;Status : Open&lt;br&gt;&lt;br&gt;Click on the below link to see the inquiry details and post additional comments.&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;{var site_url}admin/tickets/&lt;br&gt;&lt;br&gt;Regards&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;The {var site_name} Team&lt;/p&gt;', 1),
(16, 'code11', 'Client Welcome Email', 'Welcome Email', '&lt;p&gt;Hello {var client_name},&lt;/p&gt;&lt;p&gt;Welcome to {var site_name} .Thanks for joining {var site_name}. We listed your sign in details below, make sure you keep them safe. You can login to your panel using email and password.&lt;/p&gt;&lt;p&gt;Your Email Address: {var email}&lt;br&gt;&lt;/p&gt;&lt;p&gt;Your Password: {var password}&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; hr=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; client=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; client=\&quot;\\\\\&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn\&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}client/&lt;/p&gt;&lt;p&gt;Have fun!&lt;/p&gt;&lt;p&gt;The {var site_name} Team.&lt;/p&gt;', 1),
(17, 'code12', 'Password Changed Successfully', 'Password Changed Successfully', '&lt;p&gt;Hello,&lt;/p&gt;&lt;p&gt;Congratulations! Your password has been updated successfully.&lt;/p&gt;&lt;p&gt;Your new password is: {var password}&lt;/p&gt;&lt;p&gt;Thank you,&lt;br&gt;The {var site_name} Team&lt;br&gt;&lt;/p&gt;', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_accommodation`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_accommodation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accommodation_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `period_from` varchar(250) NOT NULL,
  `period_to` varchar(250) NOT NULL,
  `rent_paid` decimal(13,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_accommodation`
		--
		INSERT INTO `xin_employee_accommodation` (`id`, `accommodation_id`, `employee_id`, `period_from`, `period_to`, `rent_paid`, `created_at`, `updated_at`) VALUES
(3, 4, 8, '22-01-2023', '24-01-2023', '', '2023-01-19 06:33:47', ''),
(7, 9, 7, '02-10-2023', '04-10-2023', 100.00, '2023-10-05 03:32:31', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_bankaccount`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_bankaccount` (
  `bankaccount_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL,
  `account_title` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_code` varchar(255) NOT NULL,
  `bank_branch` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`bankaccount_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_bankaccount`
		--
		INSERT INTO `xin_employee_bankaccount` (`bankaccount_id`, `employee_id`, `is_primary`, `account_title`, `account_number`, `bank_name`, `bank_code`, `bank_branch`, `created_at`) VALUES
(1, 8, 0, 'Salary Bank Account', 438939466, 'DBS', 7171, '', '30-11-2022'),
(125, 6, 0, 'Debit card', 123456789, 'POSB', 123456, 'North point', '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_claim`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_claim` (
  `claim_id` int(11) NOT NULL AUTO_INCREMENT,
  `claim_type_id` int(11) NOT NULL,
  `claim_year` varchar(250) NOT NULL,
  `amount` double(20,2) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_claim`
		--
		INSERT INTO `xin_employee_claim` (`claim_id`, `claim_type_id`, `claim_year`, `amount`, `employee_id`, `created_at`) VALUES
(6, 3, 2023, 100.00, 6, '2023-10-01 21:27:50'),
(7, 2, 2023, 500.00, 6, '2023-10-01 21:28:15'),
(8, 4, 2023, 200.00, 6, '2023-10-01 21:46:03');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_complaints`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_complaints` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `complaint_from` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `complaint_date` varchar(255) NOT NULL,
  `complaint_against` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_contacts`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_contacts` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `is_primary` int(11) NOT NULL,
  `is_dependent` int(11) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `work_phone` varchar(255) NOT NULL,
  `work_phone_extension` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `work_email` varchar(255) NOT NULL,
  `personal_email` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_contacts`
		--
		INSERT INTO `xin_employee_contacts` (`contact_id`, `employee_id`, `relation`, `is_primary`, `is_dependent`, `contact_name`, `work_phone`, `work_phone_extension`, `mobile_phone`, `home_phone`, `work_email`, `personal_email`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `created_at`) VALUES
(4, 6, 'Spouse', 1, 0, 'abc', 12345678, '', 12345678, '', 'abc@123.com', '', '', '', '', '', '', '', '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_contract`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_contract` (
  `contract_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `contract_type_id` int(11) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_contract`
		--
		INSERT INTO `xin_employee_contract` (`contract_id`, `employee_id`, `contract_type_id`, `from_date`, `designation_id`, `title`, `to_date`, `description`, `created_at`) VALUES
(3, 6, 9, '11-09-2023', 17, '6 month internship', '09-02-2024', 'Business analyst', '02-10-2023'),
(4, 6, 1, '02-10-2023', 17, 'PM', '06-10-2023', 'sfdsfs', '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_contribution_funds`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_contribution_funds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `contribution_id` int(11) NOT NULL,
  `contribution_type` int(11) DEFAULT NULL COMMENT '1=SHG, 2=ASHG',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_contribution_funds`
		--
		INSERT INTO `xin_employee_contribution_funds` (`id`, `employee_id`, `contribution_id`, `contribution_type`, `created_at`, `updated_at`) VALUES
(3, 8, 1, 1, '2023-01-19 06:04:32', ''),
(6, 139, 1, 1, '2023-04-20 00:58:19', ''),
(7, 139, 1, 2, '2023-04-20 00:58:19', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_documents`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_documents` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `document_type_id` int(11) NOT NULL,
  `date_of_expiry` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `notification_email` varchar(255) NOT NULL,
  `is_alert` tinyint(1) NOT NULL,
  `description` mediumtext NOT NULL,
  `document_file` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_driver_benefits`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_driver_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `benefit_year` year(4) NOT NULL,
  `driver_wage` decimal(13,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_exit`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_exit` (
  `exit_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `exit_date` varchar(255) NOT NULL,
  `exit_type_id` int(11) NOT NULL,
  `exit_interview` int(11) NOT NULL,
  `is_inactivate_account` int(11) NOT NULL,
  `reason` mediumtext NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`exit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_exit_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_exit_type` (
  `exit_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`exit_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_exit_type`
		--
		INSERT INTO `xin_employee_exit_type` (`exit_type_id`, `company_id`, `type`, `created_at`) VALUES
(2, 0, 'Resign', '07-04-2021 02:11:55'),
(3, 0, 'Terminated', '07-04-2021 02:11:59');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_hotel_accommodation_benefits`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_hotel_accommodation_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `hotel_name` varchar(128) DEFAULT NULL,
  `check_in` varchar(250) NOT NULL,
  `check_out` varchar(250) NOT NULL,
  `actual_cost` decimal(13,2) NOT NULL,
  `employee_paid` decimal(13,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_housekeeping_benefits`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_housekeeping_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `benefit_year` year(4) NOT NULL,
  `housekeeping_service` varchar(128) DEFAULT NULL,
  `housekeeping_remark` varchar(128) DEFAULT NULL,
  `housekeeping_amount` decimal(13,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_immigration`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_immigration` (
  `immigration_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `document_type_id` int(11) NOT NULL,
  `document_number` varchar(255) NOT NULL,
  `document_file` varchar(255) NOT NULL,
  `issue_date` varchar(255) NOT NULL,
  `expiry_date` varchar(255) DEFAULT NULL,
  `country_id` varchar(255) NOT NULL,
  `eligible_review_date` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`immigration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_immigration`
		--
		INSERT INTO `xin_employee_immigration` (`immigration_id`, `employee_id`, `document_type_id`, `document_number`, `document_file`, `issue_date`, `expiry_date`, `country_id`, `eligible_review_date`, `comments`, `created_at`) VALUES
(89, 6, 4, 'T1234567H', 'document_1696217578.png', '02-10-2023', '06-10-2023', 195, '02-10-2023', '', '02-10-2023 03:32:58'),
(90, 5, 4, 12321, 'document_1696471151.jpg', '01-10-2023', '31-10-2023', '', '', '', '05-10-2023 01:59:11'),
(91, 7, 2, 'test', 'document_1696490360.jpg', '01-10-2023', '04-10-2023', 195, '', '', '05-10-2023 07:19:19');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_immigration_status`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_immigration_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `immigration_id` int(11) NOT NULL,
  `issue_date` varchar(250) DEFAULT NULL,
  `expire_date` varchar(250) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_immigration_status`
		--
		INSERT INTO `xin_employee_immigration_status` (`id`, `employee_id`, `immigration_id`, `issue_date`, `expire_date`, `created_at`, `updated_at`) VALUES
(1, 14, 1, '', '', '2023-02-08 06:22:48', ''),
(2, 9, 2, '10-09-2015', '', '2023-02-08 23:39:20', '2023-02-27 08:07:37'),
(3, 8, 2, '12-05-2022', '', '2023-02-09 03:29:59', '2023-02-27 08:07:24'),
(4, 10, 1, '', '', '2023-02-09 04:36:17', ''),
(5, 15, 1, '', '', '2023-02-09 04:48:23', ''),
(6, 16, 3, '', '', '2023-02-14 23:33:10', ''),
(7, 17, 1, '', '', '2023-02-15 02:51:41', ''),
(8, 18, 1, '', '', '2023-02-15 03:19:17', ''),
(9, 19, 3, '', '', '2023-02-16 04:18:41', ''),
(10, 20, 1, '', '', '2023-02-16 04:37:19', ''),
(11, 21, 3, '', '', '2023-02-16 21:17:12', ''),
(12, 22, 3, '', '', '2023-02-16 22:05:47', ''),
(13, 23, 1, '', '', '2023-02-18 07:49:22', ''),
(14, 24, 1, '', '', '2023-02-18 07:57:08', ''),
(15, 25, 1, '', '', '2023-02-22 02:27:45', ''),
(16, 26, 1, '', '', '2023-02-22 04:30:44', ''),
(17, 27, 1, '', '', '2023-02-22 04:37:01', ''),
(18, 28, 1, '', '', '2023-02-22 22:20:26', ''),
(19, 29, 1, '', '', '2023-02-22 22:30:35', ''),
(20, 30, 1, '', '', '2023-02-22 23:06:02', ''),
(21, 31, 1, '', '', '2023-02-22 23:36:12', ''),
(22, 32, 1, '', '', '2023-02-22 23:44:17', ''),
(23, 33, 1, '', '', '2023-02-22 23:53:10', ''),
(24, 34, 1, '', '', '2023-02-23 00:28:01', ''),
(25, 35, 1, '', '', '2023-02-23 02:47:05', ''),
(26, 36, 1, '', '', '2023-02-23 02:54:00', ''),
(27, 37, 1, '', '', '2023-02-23 03:00:20', ''),
(28, 38, 1, '', '', '2023-02-23 03:06:57', ''),
(29, 39, 1, '', '', '2023-02-23 03:12:37', ''),
(30, 40, 1, '', '', '2023-02-23 03:41:26', ''),
(31, 41, 1, '', '', '2023-02-23 03:52:57', ''),
(32, 42, 1, '', '', '2023-02-23 04:01:14', ''),
(34, 44, 1, '', '', '2023-03-01 00:27:28', ''),
(35, 45, 1, '', '', '2023-03-01 02:40:17', ''),
(36, 46, 1, '', '', '2023-03-01 02:51:00', ''),
(37, 47, 1, '', '', '2023-03-02 21:49:01', ''),
(38, 48, 1, '', '', '2023-03-02 21:58:44', ''),
(39, 49, 1, '', '', '2023-03-02 22:04:09', ''),
(40, 50, 1, '', '', '2023-03-02 22:10:41', ''),
(41, 51, 1, '', '', '2023-03-02 22:33:43', ''),
(42, 52, 1, '', '', '2023-03-02 22:40:03', ''),
(43, 53, 1, '', '', '2023-03-02 22:45:34', ''),
(44, 54, 1, '', '', '2023-03-02 22:55:05', ''),
(45, 55, 1, '', '', '2023-03-02 23:13:13', ''),
(46, 56, 1, '', '', '2023-03-02 23:24:53', ''),
(47, 57, 1, '', '', '2023-03-02 23:35:45', ''),
(48, 58, 1, '', '', '2023-03-02 23:45:58', ''),
(49, 59, 1, '', '', '2023-03-03 00:01:58', ''),
(50, 60, 1, '', '', '2023-03-06 02:46:28', ''),
(51, 61, 1, '', '', '2023-03-06 03:07:03', ''),
(52, 62, 1, '', '', '2023-03-06 03:14:17', ''),
(53, 63, 2, '14-09-2017', '', '2023-03-06 03:46:06', '2023-03-06 03:52:37'),
(54, 64, 2, '22-08-1997', '', '2023-03-07 22:49:08', '2023-03-07 22:56:15'),
(55, 65, 2, '08-05-2018', '', '2023-03-07 23:04:04', '2023-03-07 23:05:00'),
(56, 66, 2, '15-03-2021', '', '2023-03-07 23:33:04', '2023-03-07 23:37:39'),
(57, 67, 2, '25-07-2017', '', '2023-03-08 02:21:49', '2023-03-08 02:22:55'),
(58, 68, 3, '', '', '2023-03-08 03:10:53', ''),
(59, 69, 3, '', '', '2023-03-08 20:27:01', ''),
(60, 70, 3, '', '', '2023-03-08 21:08:48', ''),
(61, 71, 3, '', '', '2023-03-08 21:16:07', ''),
(62, 73, 3, '', '', '2023-03-08 21:25:44', ''),
(63, 74, 3, '', '', '2023-03-08 21:36:10', ''),
(64, 75, 3, '', '', '2023-03-08 21:42:53', ''),
(65, 76, 3, '', '', '2023-03-08 21:50:59', ''),
(66, 77, 3, '', '', '2023-03-08 22:13:53', ''),
(67, 78, 3, '', '', '2023-03-08 22:58:56', ''),
(68, 79, 3, '', '', '2023-03-08 23:09:36', ''),
(69, 80, 3, '', '', '2023-03-08 23:19:40', ''),
(70, 83, 3, '', '', '2023-03-09 00:03:14', ''),
(71, 84, 3, '', '', '2023-03-09 23:22:33', ''),
(72, 85, 3, '', '', '2023-03-09 23:33:42', ''),
(73, 86, 3, '', '', '2023-03-09 23:53:12', ''),
(74, 87, 3, '', '', '2023-03-10 04:23:58', ''),
(75, 88, 3, '', '', '2023-03-10 04:33:29', ''),
(76, 89, 3, '', '', '2023-03-14 23:40:34', ''),
(77, 90, 3, '', '', '2023-03-14 23:59:03', ''),
(78, 91, 3, '', '', '2023-03-15 00:36:01', ''),
(79, 92, 3, '', '', '2023-03-15 00:46:35', ''),
(80, 93, 3, '', '', '2023-03-15 00:54:14', ''),
(81, 94, 3, '', '', '2023-03-15 01:14:53', ''),
(82, 95, 3, '', '', '2023-03-15 23:24:35', ''),
(83, 96, 3, '', '', '2023-03-15 23:34:07', ''),
(84, 97, 3, '', '', '2023-03-15 23:42:44', ''),
(85, 98, 3, '', '', '2023-03-15 23:52:31', ''),
(86, 99, 3, '', '', '2023-03-16 00:12:11', ''),
(87, 100, 3, '', '', '2023-03-16 00:43:12', ''),
(88, 101, 3, '', '', '2023-03-16 00:55:27', ''),
(89, 102, 3, '', '', '2023-03-16 01:04:19', ''),
(90, 103, 3, '', '', '2023-03-16 01:23:57', ''),
(91, 104, 3, '', '', '2023-03-16 03:36:12', ''),
(92, 105, 3, '', '', '2023-03-16 03:59:04', ''),
(93, 106, 3, '', '', '2023-03-16 04:08:10', ''),
(94, 107, 3, '', '', '2023-03-16 04:15:57', ''),
(95, 108, 3, '', '', '2023-03-16 04:23:53', ''),
(96, 109, 3, '', '', '2023-03-16 04:32:00', ''),
(97, 110, 3, '', '', '2023-03-16 04:46:20', ''),
(98, 111, 3, '', '', '2023-03-16 04:57:30', ''),
(99, 112, 3, '', '', '2023-03-16 05:25:02', ''),
(100, 113, 3, '', '', '2023-03-16 05:32:41', ''),
(101, 114, 3, '', '', '2023-03-16 05:38:38', ''),
(102, 115, 3, '', '', '2023-03-16 05:53:55', ''),
(103, 116, 3, '', '', '2023-03-16 22:07:15', ''),
(104, 117, 3, '', '', '2023-03-16 22:16:01', ''),
(105, 118, 3, '', '', '2023-03-16 22:30:54', ''),
(106, 119, 3, '', '', '2023-03-16 22:44:38', ''),
(107, 120, 3, '', '', '2023-03-16 23:04:13', ''),
(108, 121, 3, '', '', '2023-03-16 23:16:47', ''),
(109, 122, 3, '', '', '2023-03-16 23:27:21', ''),
(110, 123, 3, '', '', '2023-03-16 23:34:36', ''),
(111, 124, 3, '', '', '2023-03-16 23:42:08', ''),
(112, 125, 3, '', '', '2023-03-16 23:49:48', ''),
(113, 126, 3, '', '', '2023-03-17 00:05:39', ''),
(114, 127, 3, '', '', '2023-03-17 00:21:39', ''),
(115, 128, 3, '', '', '2023-03-17 00:32:06', ''),
(116, 129, 3, '', '', '2023-03-17 00:42:21', ''),
(117, 130, 3, '', '', '2023-03-17 00:48:00', ''),
(118, 131, 1, '', '', '2023-03-17 05:35:49', ''),
(119, 132, 1, '', '', '2023-03-22 22:55:24', ''),
(120, 133, 1, '', '', '2023-03-22 23:12:11', ''),
(121, 134, 1, '', '', '2023-03-22 23:23:48', ''),
(122, 135, 1, '', '', '2023-03-23 00:09:35', ''),
(123, 136, 1, '', '', '2023-03-23 00:19:57', ''),
(124, 137, 1, '', '', '2023-03-23 00:24:25', ''),
(125, 138, 1, '', '', '2023-03-23 00:27:54', ''),
(126, 139, 1, '', '', '2023-03-23 00:31:01', ''),
(127, 140, 1, '', '', '2023-04-18 06:28:30', ''),
(128, 141, 1, '', '', '2023-05-09 05:58:28', ''),
(129, 1, 2, '05-09-2023', '', '2023-09-13 05:28:14', '2023-09-13 05:53:04'),
(130, 2, 3, '', '', '2023-09-13 06:01:16', ''),
(131, 3, 3, '', '', '2023-09-13 22:10:03', ''),
(132, 4, 1, '', '', '2023-09-18 23:23:14', ''),
(133, 5, 1, '', '', '2023-09-29 04:08:06', ''),
(134, 6, 1, '', '', '2023-10-01 21:15:03', ''),
(135, 7, 3, '', '', '2023-10-04 22:28:39', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_leave`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_leave` (
  `leave_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `contract_id` int(11) NOT NULL,
  `casual_leave` varchar(255) NOT NULL,
  `medical_leave` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_location`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_location` (
  `office_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`office_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_other_benefits`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_other_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `benefit_year` year(4) NOT NULL,
  `other_benefit` varchar(256) NOT NULL,
  `other_benefit_remark` varchar(256) DEFAULT NULL,
  `other_benefit_cost` decimal(13,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_overtime`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_overtime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `overtime_date` varchar(250) NOT NULL,
  `in_time` varchar(250) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `total_hours` time NOT NULL,
  `reason` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_overtime_rate`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_overtime_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `overtime_rate_type` int(11) NOT NULL,
  `overtime_rate` decimal(13,2) NOT NULL,
  `overtime_pay_rate` decimal(13,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_overtime_rate`
		--
		INSERT INTO `xin_employee_overtime_rate` (`id`, `employee_id`, `overtime_rate_type`, `overtime_rate`, `overtime_pay_rate`, `created_at`, `updated_at`) VALUES
(1, 8, 2, 40.00, 40.00, '2023-01-19 05:36:32', ''),
(2, 25, 2, 300.00, 300.00, '2023-02-22 04:22:21', ''),
(3, 43, 2, 10.00, 10.00, '2023-02-26 12:22:24', '2023-02-27 03:34:45'),
(4, 69, 2, 10.00, 10.00, '2023-03-08 20:55:49', ''),
(5, 75, 2, 400.00, 400.00, '2023-03-08 21:48:31', ''),
(6, 139, 2, 50.00, 50.00, '2023-04-20 00:58:08', ''),
(7, 6, 2, 10.00, 10.00, '2023-10-01 21:26:07', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_promotions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_promotions` (
  `promotion_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `promotion_date` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `designation_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_qualification`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_qualification` (
  `qualification_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `education_level_id` int(11) NOT NULL,
  `from_year` varchar(255) NOT NULL,
  `language_id` int(11) NOT NULL,
  `to_year` varchar(255) NOT NULL,
  `skill_id` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`qualification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_qualification`
		--
		INSERT INTO `xin_employee_qualification` (`qualification_id`, `employee_id`, `name`, `education_level_id`, `from_year`, `language_id`, `to_year`, `skill_id`, `description`, `created_at`) VALUES
(1, 6, 'Singapore Poly', 3, '02-10-2023', 1, '06-10-2023', 1, 'Diploma in Information Technology', '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_resignations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_resignations` (
  `resignation_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `notice_date` varchar(255) NOT NULL,
  `resignation_date` varchar(255) NOT NULL,
  `reason` mediumtext NOT NULL,
  `added_by` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`resignation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_security_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_security_level` (
  `security_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `security_type` int(11) NOT NULL,
  `date_of_clearance` varchar(200) NOT NULL,
  `expiry_date` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`security_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_share_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_share_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `so_scheme` int(11) NOT NULL,
  `so_plan` int(11) NOT NULL,
  `date_of_grant` varchar(250) NOT NULL,
  `date_of_excercise` varchar(250) NOT NULL,
  `excercise_price` decimal(13,5) NOT NULL,
  `price_date_of_grant` decimal(13,5) DEFAULT NULL,
  `price_date_of_excercise` decimal(13,5) NOT NULL,
  `no_of_shares` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_share_options`
		--
		INSERT INTO `xin_employee_share_options` (`id`, `company_id`, `employee_id`, `so_scheme`, `so_plan`, `date_of_grant`, `date_of_excercise`, `excercise_price`, `price_date_of_grant`, `price_date_of_excercise`, `no_of_shares`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 139, 2, 1, '12-04-2023', '13-04-2023', 20.00000, 20.00000, 25.00000, 2, '', '2023-04-20 00:58:59', ''),
(2, 10, 6, 1, 1, '02-10-2023', '02-10-2023', 100.00000, 100.00000, 100.00000, 100, '', '2023-10-01 21:27:32', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_shift`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_shift` (
  `emp_shift_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`emp_shift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_terminations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_terminations` (
  `termination_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `terminated_by` int(11) NOT NULL,
  `termination_type_id` int(11) NOT NULL,
  `termination_date` varchar(255) NOT NULL,
  `notice_date` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`termination_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_transfer`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_transfer` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `transfer_date` varchar(255) NOT NULL,
  `transfer_department` int(11) NOT NULL,
  `transfer_location` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_travels`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_travels` (
  `travel_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `visit_purpose` varchar(255) NOT NULL,
  `visit_place` varchar(255) NOT NULL,
  `travel_mode` int(11) DEFAULT NULL,
  `arrangement_type` int(11) DEFAULT NULL,
  `expected_budget` varchar(255) NOT NULL,
  `actual_budget` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`travel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_travels`
		--
		INSERT INTO `xin_employee_travels` (`travel_id`, `company_id`, `employee_id`, `start_date`, `end_date`, `visit_purpose`, `visit_place`, `travel_mode`, `arrangement_type`, `expected_budget`, `actual_budget`, `description`, `status`, `added_by`, `created_at`) VALUES
(1, 1, 2, '27-09-2023', '30-09-2023', 'relax', 'sg', 1, 1, '', '', '', 1, 1, '29-09-2023'),
(2, 10, 6, '02-10-2023', '05-10-2023', 'Holiday', 'Hong Kong', 1, 1, '', '', '', 1, 1, '02-10-2023'),
(3, 10, 6, '02-10-2023', '04-10-2023', 'Holiday', 'China', 2, 1, 100, 500, '', 1, 1, '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_utility_benefits`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_utility_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `benefit_year` year(4) NOT NULL,
  `utility` varchar(128) DEFAULT NULL,
  `utility_remark` varchar(128) DEFAULT NULL,
  `utility_amount` decimal(13,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_warnings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_warnings` (
  `warning_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `warning_to` int(11) NOT NULL,
  `warning_by` int(11) NOT NULL,
  `warning_date` varchar(255) NOT NULL,
  `warning_type_id` int(11) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`warning_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_work_experience`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_work_experience` (
  `work_experience_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`work_experience_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_year_leave`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_year_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_type_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `leave_year` year(4) NOT NULL,
  `no_of_leaves` decimal(10,1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=412 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employee_year_leave`
		--
		INSERT INTO `xin_employee_year_leave` (`id`, `leave_type_id`, `employee_id`, `leave_year`, `no_of_leaves`, `created_at`, `updated_at`) VALUES
(411, 6, 7, 2023, 10.0, '2023-10-05 03:24:19', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employees` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(200) NOT NULL,
  `office_shift_id` int(11) NOT NULL,
  `reports_to` int(11) NOT NULL DEFAULT 0,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `date_of_birth` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `e_status` int(11) NOT NULL,
  `user_role_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `sub_department_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `location_id` int(11) NOT NULL,
  `view_companies_id` varchar(255) NOT NULL,
  `salary_template` varchar(255) NOT NULL,
  `hourly_grade_id` int(11) NOT NULL,
  `monthly_grade_id` int(11) NOT NULL,
  `date_of_joining` varchar(200) NOT NULL,
  `confirmation_date` varchar(250) NOT NULL,
  `date_of_leaving` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `salary` varchar(200) NOT NULL,
  `wages_type` int(11) NOT NULL,
  `basic_salary` varchar(200) NOT NULL DEFAULT '0',
  `daily_wages` varchar(200) NOT NULL DEFAULT '0',
  `salary_ssempee` varchar(200) NOT NULL DEFAULT '0',
  `salary_ssempeer` varchar(200) DEFAULT '0',
  `salary_income_tax` varchar(200) NOT NULL DEFAULT '0',
  `salary_overtime` varchar(200) NOT NULL DEFAULT '0',
  `salary_commission` varchar(200) NOT NULL DEFAULT '0',
  `salary_claims` varchar(200) NOT NULL DEFAULT '0',
  `salary_paid_leave` varchar(200) NOT NULL DEFAULT '0',
  `salary_director_fees` varchar(200) NOT NULL DEFAULT '0',
  `salary_bonus` varchar(200) NOT NULL DEFAULT '0',
  `salary_advance_paid` varchar(200) NOT NULL DEFAULT '0',
  `address` mediumtext NOT NULL,
  `vaccination` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `zipcode` varchar(200) NOT NULL,
  `id_type` int(11) DEFAULT NULL,
  `id_no` varchar(45) DEFAULT NULL,
  `profile_picture` mediumtext NOT NULL,
  `profile_background` mediumtext NOT NULL,
  `resume` mediumtext NOT NULL,
  `skype_id` varchar(200) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `facebook_link` mediumtext NOT NULL,
  `twitter_link` mediumtext NOT NULL,
  `blogger_link` mediumtext NOT NULL,
  `linkdedin_link` mediumtext NOT NULL,
  `google_plus_link` mediumtext NOT NULL,
  `instagram_link` varchar(255) NOT NULL,
  `pinterest_link` varchar(255) NOT NULL,
  `youtube_link` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `online_status` int(11) NOT NULL,
  `fixed_header` varchar(150) NOT NULL,
  `compact_sidebar` varchar(150) NOT NULL,
  `boxed_wrapper` varchar(150) NOT NULL,
  `ethnicity_type` int(11) NOT NULL,
  `blood_group` varchar(50) DEFAULT NULL,
  `nationality_id` int(11) NOT NULL,
  `citizenship_id` int(11) NOT NULL,
  `leave_categories` varchar(200) NOT NULL,
  `passport_number` varchar(250) DEFAULT NULL,
  `work_permit_number` varchar(250) DEFAULT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_employees`
		--
		INSERT INTO `xin_employees` (`user_id`, `employee_id`, `office_shift_id`, `reports_to`, `first_name`, `last_name`, `username`, `email`, `password`, `date_of_birth`, `gender`, `e_status`, `user_role_id`, `department_id`, `sub_department_id`, `designation_id`, `company_id`, `location_id`, `view_companies_id`, `salary_template`, `hourly_grade_id`, `monthly_grade_id`, `date_of_joining`, `confirmation_date`, `date_of_leaving`, `marital_status`, `salary`, `wages_type`, `basic_salary`, `daily_wages`, `salary_ssempee`, `salary_ssempeer`, `salary_income_tax`, `salary_overtime`, `salary_commission`, `salary_claims`, `salary_paid_leave`, `salary_director_fees`, `salary_bonus`, `salary_advance_paid`, `address`, `vaccination`, `state`, `city`, `zipcode`, `id_type`, `id_no`, `profile_picture`, `profile_background`, `resume`, `skype_id`, `contact_no`, `facebook_link`, `twitter_link`, `blogger_link`, `linkdedin_link`, `google_plus_link`, `instagram_link`, `pinterest_link`, `youtube_link`, `is_active`, `last_login_date`, `last_logout_date`, `last_login_ip`, `is_logged_in`, `online_status`, `fixed_header`, `compact_sidebar`, `boxed_wrapper`, `ethnicity_type`, `blood_group`, `nationality_id`, `citizenship_id`, `leave_categories`, `passport_number`, `work_permit_number`, `created_at`) VALUES
(1, 000, 50, 0, 'Human', 'resource', 'superadmin', 'superadmin@gmail.com', '$2y$10$YTlDWp0H0PdWnfdpAjYFqu6XiZX7q7MyEO8zLObGMx6nNWHAjIeja', '05-10-2023', 'Male', 0, 1, 6, 3, 15, 10, 2, 0, 'monthly', 0, 0, '02-01-2018', '', '22-09-2023', 'Single', '', 1, 1000, 0, 8, 17, 10, 0, 1, 2, 3, 0, 0, 0, 'Test Address', '', '', '', '', 1, 'S1230001A', 'profile_1546421723.png', 'profile_background_1519924152.jpg', '', '', 83157649, '', '', '', '', '', '', '', '', 1, '06-10-2023 08:41:35', '05-10-2023 16:13:57', '61.16.77.154', 1, 1, '', '', '', 0, '', 0, 0, 0, '', '', '2018-02-28 05:30:44');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_ethnicity_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_ethnicity_type` (
  `ethnicity_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`ethnicity_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

		--
		-- Dumping data for table `xin_ethnicity_type`
		--
		INSERT INTO `xin_ethnicity_type` (`ethnicity_type_id`, `type`, `created_at`) VALUES
(1, 'Hindu', '01-09-2022 01:58:34'),
(2, 'Muslim', '29-11-2022 01:41:05'),
(3, 'Buddhist', '29-11-2022 01:41:30'),
(4, 'Christian', '29-11-2022 01:41:40');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_events`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` varchar(255) DEFAULT NULL,
  `event_title` varchar(255) NOT NULL,
  `event_date` varchar(255) NOT NULL,
  `event_time` varchar(255) NOT NULL,
  `event_note` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_expense_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_expense_type` (
  `expense_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_expenses`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `expense_type_id` int(11) NOT NULL,
  `billcopy_file` mediumtext NOT NULL,
  `amount` varchar(200) NOT NULL,
  `purchase_date` varchar(200) NOT NULL,
  `remarks` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `status_remarks` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_file_manager`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_file_manager` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `file_extension` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_file_manager_settings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_file_manager_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `allowed_extensions` mediumtext NOT NULL,
  `maximum_file_size` varchar(255) NOT NULL,
  `is_enable_all_files` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_file_manager_settings`
		--
		INSERT INTO `xin_file_manager_settings` (`setting_id`, `allowed_extensions`, `maximum_file_size`, `is_enable_all_files`, `updated_at`) VALUES
(1, 'gif,png,pdf,txt,doc,docx', 10, '', '2019-09-30 03:13:58');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_bankcash`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_bankcash` (
  `bankcash_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) NOT NULL,
  `account_balance` varchar(255) NOT NULL,
  `account_opening_balance` varchar(200) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch_code` varchar(255) NOT NULL,
  `bank_branch` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`bankcash_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_deposit`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_deposit` (
  `deposit_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `deposit_date` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `payer_id` int(11) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `deposit_reference` varchar(255) NOT NULL,
  `deposit_file` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`deposit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_expense`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_expense` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `expense_date` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `payee_id` int(11) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `expense_reference` varchar(255) NOT NULL,
  `expense_file` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_payees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_payees` (
  `payee_id` int(11) NOT NULL AUTO_INCREMENT,
  `payee_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_payers`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_payers` (
  `payer_id` int(11) NOT NULL AUTO_INCREMENT,
  `payer_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_transaction`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `transaction_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `amount` float NOT NULL,
  `transaction_type` varchar(100) NOT NULL,
  `dr_cr` enum('dr','cr') NOT NULL,
  `transaction_cat_id` int(11) NOT NULL,
  `payer_payee_id` int(11) NOT NULL,
  `payee_option` int(11) DEFAULT NULL,
  `payment_method_id` int(11) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `invoice_type` varchar(100) DEFAULT NULL,
  `attachment_file` varchar(100) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

		--
		-- Dumping data for table `xin_finance_transaction`
		--
		INSERT INTO `xin_finance_transaction` (`transaction_id`, `account_id`, `company_id`, `transaction_date`, `description`, `amount`, `transaction_type`, `dr_cr`, `transaction_cat_id`, `payer_payee_id`, `payee_option`, `payment_method_id`, `reference`, `invoice_id`, `client_id`, `invoice_type`, `attachment_file`, `created_at`) VALUES
(1, 1, 0, '2023-01-31', 'Award Payments', 10, 'expense', 'cr', 0, 8, '', 3, 'Award Payments', 1, 8, '', '', '2023-01-31 18:03:57'),
(2, 1, 0, '2023-01-31', 'Award Payments', 111, 'expense', 'cr', 0, 8, '', 3, 'Award Payments', 2, 8, '', '', '2023-01-31 18:05:27'),
(3, 1, 0, '2023-01-31', 'Award Payments', 10, 'expense', 'cr', 0, 8, '', 3, 'Award Payments', 3, 8, '', '', '2023-01-31 18:08:00'),
(4, 1, 0, '2023-01-31', 'Award Payments', 0, 'expense', 'cr', 0, 8, '', 3, 'Award Payments', 4, 8, '', '', '2023-01-31 18:16:35'),
(5, 1, 0, '2023-02-27', 'Award Payments', 0, 'expense', 'cr', 0, 43, '', 3, 'Award Payments', 5, 43, '', '', '2023-02-27 01:38:01'),
(6, 1, 0, '2023-02-27', 'Travel Expense', 0, 'expense', 'cr', 0, 43, '', 3, 'Travel Expense', 2, 43, '', '', '2023-02-27 01:54:05'),
(7, 1, 0, '2023-02-27', 'Award Payments', 0, 'expense', 'cr', 0, 43, '', 3, 'Award Payments', 6, 43, '', '', '2023-02-27 01:59:04'),
(8, 1, 0, '2023-02-27', 'Travel Expense', 0, 'expense', 'cr', 0, 43, '', 3, 'Travel Expense', 3, 43, '', '', '2023-02-27 02:01:53'),
(9, 1, 0, '2023-02-27', 'Travel Expense', 0, 'expense', 'cr', 0, 43, '', 3, 'Travel Expense', 3, 43, '', '', '2023-02-27 02:16:37'),
(10, 1, 0, '2023-02-27', 'Travel Expense', 0, 'expense', 'cr', 0, 43, '', 3, 'Travel Expense', 2, 43, '', '', '2023-02-27 02:17:23'),
(11, 1, 0, '2023-02-27', 'Travel Expense', 0, 'expense', 'cr', 0, 43, '', 3, 'Travel Expense', 2, 43, '', '', '2023-02-27 02:17:51'),
(12, 1, 0, '2023-09-29', 'Award Payments', 0, 'expense', 'cr', 0, 2, '', 3, 'Award Payments', 7, 2, '', '', '2023-09-29 08:56:18'),
(13, 1, 0, '2023-10-02', 'Award Payments', 100, 'expense', 'cr', 0, 6, '', 3, 'Award Payments', 8, 6, '', '', '2023-10-02 01:21:13'),
(14, 1, 0, '2023-10-02', 'Travel Expense', 0, 'expense', 'cr', 0, 6, '', 3, 'Travel Expense', 2, 6, '', '', '2023-10-02 01:29:14'),
(15, 1, 0, '2023-10-02', 'Travel Expense', 500, 'expense', 'cr', 0, 6, '', 3, 'Travel Expense', 3, 6, '', '', '2023-10-02 01:31:55'),
(16, 1, 0, '2023-10-05', 'Award Payments', 213, 'expense', 'cr', 0, 7, '', 3, 'Award Payments', 9, 7, '', '', '2023-10-05 07:26:41');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_transactions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `deposit_id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `transaction_debit` varchar(255) NOT NULL,
  `transaction_credit` varchar(255) NOT NULL,
  `transaction_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_transfer`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_transfer` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_account_id` int(11) NOT NULL,
  `to_account_id` int(11) NOT NULL,
  `transfer_date` varchar(255) NOT NULL,
  `transfer_amount` varchar(255) NOT NULL,
  `payment_method` varchar(111) NOT NULL,
  `transfer_reference` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_goal_tracking`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_goal_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `tracking_type_id` int(11) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `target_achiement` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `goal_progress` varchar(200) NOT NULL,
  `goal_status` int(11) NOT NULL DEFAULT 0,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_goal_tracking_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_goal_tracking_type` (
  `tracking_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`tracking_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_goal_tracking_type`
		--
		INSERT INTO `xin_goal_tracking_type` (`tracking_type_id`, `company_id`, `type_name`, `created_at`) VALUES
(1, 0, 'asdds', '31-01-2023 09:49:12'),
(2, 0, 'dkldsfjsdf', '02-10-2023 03:23:17');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_holidays`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_holidays` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `event_name` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `is_publish` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_holidays`
		--
		INSERT INTO `xin_holidays` (`holiday_id`, `company_id`, `event_name`, `description`, `start_date`, `end_date`, `is_publish`, `created_at`) VALUES
(3, 10, 'New Year 2023', '', '01-10-2023', '31-10-2023', 1, '2023-02-18'),
(5, 10, 'Chinese New Year 2023', '', '01-01-2023', '31-01-2023', 1, '2023-03-24'),
(6, 10, 'Good Friday', '', '07-04-2023', '07-04-2023', 1, '2023-03-24'),
(7, 10, 'Hari Raya Puasa', '', '22-04-2023', '22-04-2023', 1, '2023-03-24'),
(8, 10, 'Labour Day', '', '01-05-2023', '01-05-2023', 1, '2023-03-24'),
(9, 10, 'Vesak Day', '', '02-06-2023', '02-06-2023', 1, '2023-03-24'),
(10, 10, 'Hari Raya Haji', '', '29-06-2023', '29-06-2023', 1, '2023-03-24'),
(11, 10, 'National Day', '', '09-08-2023', '09-08-2023', 1, '2023-03-24'),
(12, 10, 'Deepavali', '', '12-11-2023', '13-11-2023', 1, '2023-03-24'),
(13, 10, 'Christmas Day', '', '25-12-2023', '25-12-2023', 1, '2023-03-24'),
(17, 10, 'tes', '&lt;p&gt;test&lt;/p&gt;', '14-10-2023', '30-10-2023', 1, '2023-10-06');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hourly_templates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hourly_templates` (
  `hourly_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `hourly_grade` varchar(255) NOT NULL,
  `hourly_rate` varchar(255) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`hourly_rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_invoices`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_invoices` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `invoice_date` varchar(255) NOT NULL,
  `invoice_due_date` varchar(255) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `discount_type` varchar(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `invoice_note` mediumtext NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT 'null',
  `company_name` varchar(200) NOT NULL DEFAULT 'null',
  `client_profile` varchar(200) NOT NULL DEFAULT 'null',
  `email` varchar(200) NOT NULL DEFAULT 'null',
  `contact_number` varchar(200) NOT NULL DEFAULT 'null',
  `website_url` varchar(200) NOT NULL DEFAULT 'null',
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(200) NOT NULL DEFAULT 'null',
  `state` varchar(200) NOT NULL DEFAULT 'null',
  `zipcode` varchar(200) NOT NULL DEFAULT 'null',
  `countryid` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_invoices_items`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_invoices_items` (
  `invoice_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_tax_type` varchar(255) NOT NULL,
  `item_tax_rate` varchar(255) NOT NULL,
  `item_qty` varchar(255) NOT NULL,
  `item_unit_price` varchar(255) NOT NULL,
  `item_sub_total` varchar(255) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `discount_type` int(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_module_attributes`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_module_attributes` (
  `custom_field_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `attribute_label` varchar(255) NOT NULL,
  `attribute_type` varchar(255) NOT NULL,
  `validation` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`custom_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_module_attributes_select_value`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_module_attributes_select_value` (
  `attributes_select_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(11) NOT NULL,
  `select_label` varchar(255) NOT NULL,
  PRIMARY KEY (`attributes_select_value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_module_attributes_values`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_module_attributes_values` (
  `attributes_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_attributes_id` int(11) NOT NULL,
  `attribute_value` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`attributes_value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_quotes`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_quotes` (
  `quote_id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(255) NOT NULL,
  `project_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `quote_date` varchar(255) NOT NULL,
  `quote_due_date` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `discount_type` varchar(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `tax_type` varchar(100) NOT NULL,
  `tax_figure` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `quote_type` varchar(100) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `quote_note` mediumtext NOT NULL,
  `name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `client_profile` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact_number` varchar(200) NOT NULL,
  `website_url` varchar(200) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `zipcode` varchar(200) NOT NULL,
  `countryid` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_quotes_items`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_quotes_items` (
  `quote_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_tax_type` varchar(255) NOT NULL,
  `item_tax_rate` varchar(255) NOT NULL,
  `item_qty` varchar(255) NOT NULL,
  `item_unit_price` varchar(255) NOT NULL,
  `item_sub_total` varchar(255) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `tax_type` int(11) NOT NULL,
  `tax_figure` varchar(200) NOT NULL,
  `discount_type` int(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`quote_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_immigration_status`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_immigration_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `immigration_status` varchar(256) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_immigration_status`
		--
		INSERT INTO `xin_immigration_status` (`id`, `immigration_status`, `created_at`, `updated_at`) VALUES
(1, 'Singapore Citizen', '2021-02-09 23:24:35', ''),
(2, 'Singapore PR', '2021-02-09 23:24:35', ''),
(3, 'Foreign Employee', '2021-02-09 23:24:35', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_income_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_income_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_income_categories`
		--
		INSERT INTO `xin_income_categories` (`category_id`, `name`, `status`, `created_at`) VALUES
(2, 'Salary', 1, '25-03-2018 09:36:28'),
(3, 'Other Income', 1, '25-03-2018 09:36:32'),
(4, 'Interest Income', 1, '25-03-2018 09:36:53'),
(5, 'Part Time Work', 1, '25-03-2018 09:37:13'),
(6, 'Regular Income', 1, '25-03-2018 09:37:17');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_ir8a_submission`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_ir8a_submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `efiling_id` int(11) NOT NULL,
  `submission_key` varchar(256) NOT NULL,
  `basis_year` year(4) NOT NULL,
  `no_of_records` int(11) NOT NULL,
  `total_payment` decimal(13,2) DEFAULT NULL,
  `total_salary` decimal(13,2) DEFAULT NULL,
  `total_bonus` decimal(13,2) DEFAULT NULL,
  `total_director_fee` decimal(13,2) DEFAULT NULL,
  `total_other` decimal(13,2) DEFAULT NULL,
  `total_exempt_income` decimal(13,2) DEFAULT NULL,
  `total_tax_borne_employer` decimal(13,2) DEFAULT NULL,
  `total_tax_borne_employee` decimal(13,2) DEFAULT NULL,
  `total_donation` decimal(13,2) DEFAULT NULL,
  `total_cpf` decimal(13,2) DEFAULT NULL,
  `total_insurance` decimal(13,2) DEFAULT NULL,
  `total_mbf` decimal(13,2) DEFAULT NULL,
  `ir8a_file` varchar(256) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `submission_reference` varchar(256) DEFAULT NULL,
  `submission_date` datetime DEFAULT NULL,
  `status_code` varchar(45) DEFAULT NULL,
  `response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_applications`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_applications` (
  `application_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` mediumtext NOT NULL,
  `job_resume` mediumtext NOT NULL,
  `application_status` int(11) NOT NULL DEFAULT 0,
  `application_remarks` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `category_url` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_job_categories`
		--
		INSERT INTO `xin_job_categories` (`category_id`, `category_name`, `category_url`, `created_at`) VALUES
(1, 'PHP', 'q7VJh5xWwr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(2, 'Android', 'q7VJh5xWwr56ycN0m34Aou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(3, 'WordPress', 'q2327VJh5xWwr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(4, 'Design', '0oplfq7VJh5xWwr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(5, 'Developer', '34e6zyr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(6, 'iOS', 'l1BbMd6H2D3rkFnjU9LgCq7VJh5xWwr56ycN0mAou4266iOY8', '2018-04-15'),
(7, 'Mobile', 'l1BbMd6H2D3rkFnjU9LgCH2D3rkFnjU9BbMd6H2D3r', '2018-04-15'),
(8, 'MySQL', '2D3rkFnjU9LgCq7VJh5xWwl1BbMd6H2D3rkFnjU9LgCq7VJh5xWwr56ycN0mAou4266iOY8', '2018-04-15'),
(9, 'JavaScript', 'gCq7VJh5xWwl1BbMd6H2D3rkFnjU9LgCq7VJh5xWwl1BbMd6H2D3rkFnjU9LgCq7VJh5xWwr56ycN0mAou4266iOY8', '2018-04-15'),
(10, 'Software', 'zyr56ycN0mAou42634e6zyr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(11, 'Website Design', '6iOY8l1BbMd6H2D3rkFnjU9LgCzyr56ycN0mAou42634e6zyr56ycN0mAou426', '2018-04-15'),
(12, 'Programming', 'jU9LgCzyr56ycN0mAou4266iOY8l1BbMd6H2D3rkFn34e6zyr56ycN0mAou426', '2018-04-15'),
(13, 'SEO', 'cN0mAou4266iOY8l1Bq2327VJh5xWwr56ybMd6H2D3rkFnjU9LgC', '2018-04-15'),
(14, 'Java', 'VJh5xWwr56ybMd6H2DcN0mAou4266iOY8l1Bq23273rkFnjU9LgC', '2018-04-15'),
(15, 'CSS', 'VJh5xWwr56ybMd6H2Dsdfkkj58234ksklEr6ybMd6H2D', '2018-04-15'),
(16, 'HTML5', '0349324k0434r23ksodfkpsodkfposakfkpww3MsH2Dei30ks', '2018-04-15'),
(17, 'Web Development', 'sdfj0rkskfskdfj329FLE34LFMsH2Dei30ks0349324k0434', '2018-04-15'),
(18, 'Web Design', 'MsH2Deiee30ks0349324k0434klEr6ybMd6234b5ksddif0k33', '2018-04-15'),
(19, 'eCommerce', 'klEr6ybMd6234bMsH2Dei30ks0349324k04345ksddif0k33', '2018-04-15'),
(20, 'Design', '234bMsklEr6ybMd6H2Dssdk5yy98ooVJh5xWwr56y435gghhole93lfkkj58', '2018-04-15'),
(21, 'Logo Design', 'k5yy98ooVJh5xWw45456y435gghhole93lfkkj58234bMsklEr6ybMd6H2D', '2018-04-15'),
(22, 'Graphic Design', 'k5yy98ooVJh5xWwr56y435gghhole93lfkkj58234bMsklEr6ybMd6H2D', '2018-04-15'),
(23, 'Video', 'k98ooVJh5xWwr56y435gghhole93lfkkj58234bMsklEr6ybMd6H2D', '2018-04-15'),
(24, 'Animation', 'ole93lfkkj58234k98ooVJh5xWwr56ybMsklEr6ybMd6H2D', '2018-04-15'),
(25, 'Adobe Photoshop', 'd6H2Dsdfkkj58234k98ooVJh5xWwr56ybMsklEr6ybMd6H2D', '2018-04-15'),
(26, 'Illustration', 'xWwr56ybMd6H2DcN0mA3405kfVJh5ou4266iOY8l1Bq23273rkFnjU9LgC', '2018-04-15'),
(27, 'Art', '3405kfVJh5ou4266iOY8l1Bq23273rk3ok3xWwr56ybMd6H2DcN0mAFnjU9LgC', '2018-04-15'),
(28, '3D', 'Md6H2DcN0mAFnjU9LfVJh5ou4266iOY8l1Bq23273rk3ok3xWwr56ybgC', '2018-04-15'),
(29, 'Adobe Illustrator', '5ou4266iOY8l1Bq23273rkMd6H2DcN0mAFnjU9LfVJh3ok3xWwr56ybgCww', '2018-04-15'),
(30, 'Drawing', '6iOY8l1Bq23273rk0234KILR23492034ksfpd456yslfdsf5ou426', '2018-04-15'),
(31, 'Web Design', '3l34l432fo232l3223DhssdfRKLl5434lsdfl3l3sfs3lllblp23D', '2018-04-15'),
(32, 'Cartoon', 'sdfowerewl567lflsdfl3l3sf3l34l432fo232l3223Dhs3lllblp23D', '2018-04-15'),
(33, 'Graphics', '3232l32hsfo23lllblp23D9LfVJkfo394s5ou42at5sd20cNsolof3llsblp23DcN', '2018-04-15'),
(34, 'Fashion Design', '9LfVJkfo394s5ou42at5sd203232l32hsfo23lllblp23DcNsolof3llsblp23DcN', '2018-04-15'),
(35, 'WordPress', 'hsfo23lllblp23DcNsolof3llsblp23DcN9LfVJkfo394s5ou42', '2018-04-15'),
(36, 'Editing', 'lof3llsblp23DcN9LfVJhsfo23lllblp23DcNsokfo394s5ou42', '2018-04-15'),
(37, 'Writing', 'blp23DcNsokfo394slof3llsblp23DcN9LfVJh5ou42', '2018-04-15'),
(38, 'T-Shirt Design', '9LfVJh5ou42blp23DcNsdf329LfVJh5ou42bsokjfwpoek0mAFnjU', '2018-04-15'),
(39, 'Display Advertising', '9LfVJh5ou42bsokjfwpoek9LfVJh5ou42blp23DcN0mAFnjU', '2018-04-15'),
(40, 'Email Marketing', 'DcN0mAFnjU9LfVJh5ou42bs66iOY8l1Bq23273rk3ok3xWwr56yMd6H2gC', '2018-04-15'),
(41, 'Lead Generation', '66iOY8l1Bq23273rk3ok3xWwr56yMd6H2DcN0mAFnjU9LfVJh5ou42bgC', '2018-04-15'),
(42, 'Market & Customer Research', 'Aou42Eou42iOY800Ke3klAou42066iOY800fklAou42', '2018-04-15'),
(43, 'Marketing Strategy', 'EKe3000fklAou4266iOY8l1kkadwlsdfk20323rlsKh4KadlLL', '2018-04-15'),
(44, 'Public Relations', 'l1kkadwlsdfk20323rlsKh4KadlLLEKe3000fklAou4266iOY8', '2018-04-15'),
(45, 'Telemarketing & Telesales', 'fklAou4266iOY8l1kkadwlsfBf329k3249owe923ksd324odLL2DcN0m', '2018-04-15'),
(46, 'Other - Sales & Marketing', 'Bf329k3249owe923ksd324odfklAou4266iOY8l1kkadwlLL2DcN0m', '2018-04-15'),
(47, 'SEM - Search Engine Marketing', 'Aou4266iOY8l1Bf329k3249owe923ksdkkadwlLL2DcN0m', '2018-04-15'),
(48, 'SEO - Search Engine Optimization', 'rk0234KILR23492034ksfpd456y6iOY8l1Bq23273slfdsf5ou426', '2018-04-15'),
(49, 'SMM - Social Media Marketing', '2DcN0mAou4266iOY8l1BVJh5xWwr56ybMd6Hq23273rkFnjU9LgC', '2018-04-15');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_interviews`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_interviews` (
  `job_interview_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `interviewers_id` varchar(255) NOT NULL,
  `interview_place` varchar(255) NOT NULL,
  `interview_date` varchar(255) NOT NULL,
  `interview_time` varchar(255) NOT NULL,
  `interviewees_id` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_pages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `page_details` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_job_pages`
		--
		INSERT INTO `xin_job_pages` (`page_id`, `page_title`, `page_url`, `page_details`, `created_at`) VALUES
(1, 'About Us', 'xl9wkRy7tqOehBo6YCDjFG2JTucpKI4gMNsn8Zdf', 'About Ussss', '2018-04-15'),
(2, 'Communications', '5uk4EUc3V9FYTbBQz7PWgKM6qCajfAipvhOJnZHl', 'Communications', '2018-04-15'),
(3, 'Lending Licenses', '5r6OCsUoHQFiRwI17W0eT38jbvpxEGuLhzgmt9lZ', 'Lending Licenses', '2018-04-15'),
(4, 'Terms of Service', 'QrfbMOUWpdYNxjLFz8G1m6t3wi0X2RKEZVC9ySka', 'Terms of Service', '2018-04-15'),
(5, 'Privacy Policy', 'rjHKhmsNezT2OJBAoQq0yU1tL5F34MCwgIiZEc7x', 'Privacy Policy', '2018-04-15'),
(6, 'Support', 'gZbBVMxnfzYLlC2AOk609Q7yWpaSjmJHuRXosr58', 'Support', '2018-04-15'),
(7, 'How It Works', 'l1BbMd6H2D3rkFnjU9LgCH2D3rkFnjU9BbMd6H2D3r', 'How It Works', '2018-04-15'),
(8, 'Disclaimers', 'CTbzS9IrWkNU7VM3HGZYjp6iwmfyXDOQgtsP8FEc', 'Disclaimers', '2018-04-15');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_type` (
  `job_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_job_type`
		--
		INSERT INTO `xin_job_type` (`job_type_id`, `company_id`, `type`, `type_url`, `created_at`) VALUES
(1, 1, 'Full Time', 'full-time', '22-03-2018 02:18:48'),
(2, 1, 'Part Time', 'part-time', '16-04-2018 06:29:45'),
(3, 1, 'Internship', 'internship', '16-04-2018 06:30:06'),
(4, 1, 'Freelance', 'freelance', '16-04-2018 06:30:21');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_jobs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_jobs` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `employer_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `job_url` varchar(255) NOT NULL,
  `job_type` int(11) NOT NULL,
  `category_url` varchar(255) NOT NULL,
  `is_featured` int(11) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `job_vacancy` int(11) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `minimum_experience` varchar(255) NOT NULL,
  `date_of_closing` varchar(200) NOT NULL,
  `short_description` mediumtext NOT NULL,
  `long_description` mediumtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_jobs`
		--
		INSERT INTO `xin_jobs` (`job_id`, `employer_id`, `category_id`, `company_id`, `job_title`, `designation_id`, `job_url`, `job_type`, `category_url`, `is_featured`, `type_url`, `job_vacancy`, `gender`, `minimum_experience`, `date_of_closing`, `short_description`, `long_description`, `status`, `created_at`) VALUES
(1, 2, 1, 0, 'demo', 0, 'fEsa9HiIg3kQG78KoOxTpntvZMAq6jzwRcNVWSUr', 1, '', 1, '', 5, 0, 0, '2022-12-31', 'php', '', 1, '2022-09-01 02:44:06'),
(2, 2, 1, 0, 'fsf', 0, 'BjfLNbr5FIKhXan92DWPMiVp8C1A0v3Eg6JmGYzu', 1, '', 1, '', 3, 0, 0, '2022-09-23', 'cvcfv', '', 1, '2022-09-03 05:23:09');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_kpi_incidental`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_kpi_incidental` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `incidental_kpi` text NOT NULL,
  `targeted_date` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `quarter` int(11) NOT NULL,
  `result` varchar(200) NOT NULL,
  `feedback` text NOT NULL,
  `year_created` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_kpi_maingoals`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_kpi_maingoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `main_kpi` varchar(255) NOT NULL,
  `year_created` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL,
  `approve_status` varchar(100) NOT NULL,
  `q1` varchar(100) NOT NULL,
  `q2` varchar(100) NOT NULL,
  `q3` varchar(100) NOT NULL,
  `q4` varchar(100) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_kpi_variable`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_kpi_variable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `variable_kpi` varchar(200) NOT NULL,
  `targeted_date` varchar(200) NOT NULL,
  `result` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `approve_status` varchar(200) NOT NULL,
  `feedback` text NOT NULL,
  `quarter` varchar(200) NOT NULL,
  `year_created` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_languages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_languages` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(255) NOT NULL,
  `language_code` varchar(255) NOT NULL,
  `language_flag` varchar(255) NOT NULL,
  `is_active` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_languages`
		--
		INSERT INTO `xin_languages` (`language_id`, `language_name`, `language_code`, `language_flag`, `is_active`, `created_at`) VALUES
(1, 'English', 'english', 'language_flag_1520564355.gif', 1, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leads`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leads` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `client_username` varchar(255) NOT NULL,
  `client_password` varchar(255) NOT NULL,
  `client_profile` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `is_changed` int(11) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leads_followup`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leads_followup` (
  `leads_followup_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `next_followup` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`leads_followup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leave_applications`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leave_applications` (
  `leave_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `from_date` varchar(250) NOT NULL,
  `to_date` varchar(250) NOT NULL,
  `applied_on` varchar(200) NOT NULL,
  `reason` mediumtext DEFAULT NULL,
  `remarks` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `is_half_day` tinyint(1) DEFAULT NULL,
  `is_notify` int(11) NOT NULL,
  `leave_attachment` varchar(255) DEFAULT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leave_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leave_type` (
  `leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type_name` varchar(200) NOT NULL,
  `days_per_year` varchar(250) DEFAULT NULL,
  `is_paid` tinyint(4) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_leave_type`
		--
		INSERT INTO `xin_leave_type` (`leave_type_id`, `company_id`, `type_name`, `days_per_year`, `is_paid`, `status`, `created_at`, `updated_at`) VALUES
(6, 0, 'Childcare Leave', '', 1, 1, '2021-02-09 23:24:35', ''),
(7, 0, 'Maternity Leave', '', 1, 1, '2021-02-09 23:24:35', ''),
(8, 0, 'Paternity Leave', '', 1, 1, '2021-02-09 23:24:35', ''),
(10, 0, 'Sick Leave', '', 1, 1, '2021-02-09 23:24:35', ''),
(12, 0, 'Unpaid Leave', '', 0, 1, '2021-04-07 02:11:34', ''),
(15, 0, 'B/F Leave 2022', 20, 0, 1, '0000-00-00 00:00:00', ''),
(16, 0, 'Annual Leave', '', 0, 1, '0000-00-00 00:00:00', ''),
(17, 0, 'Birthday Leave', '', 0, 1, '0000-00-00 00:00:00', ''),
(18, 0, 'Holiday in lieu', '', 0, 1, '0000-00-00 00:00:00', ''),
(20, 0, 'Incentive Leave', '', 1, 1, '2023-03-24 00:12:10', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_make_payment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_make_payment` (
  `make_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `payment_date` varchar(200) NOT NULL,
  `basic_salary` varchar(255) NOT NULL,
  `payment_amount` varchar(255) NOT NULL,
  `gross_salary` varchar(255) NOT NULL,
  `total_allowances` varchar(255) NOT NULL,
  `total_deductions` varchar(255) NOT NULL,
  `net_salary` varchar(255) NOT NULL,
  `house_rent_allowance` varchar(255) NOT NULL,
  `medical_allowance` varchar(255) NOT NULL,
  `travelling_allowance` varchar(255) NOT NULL,
  `dearness_allowance` varchar(255) NOT NULL,
  `provident_fund` varchar(255) NOT NULL,
  `tax_deduction` varchar(255) NOT NULL,
  `security_deposit` varchar(255) NOT NULL,
  `overtime_rate` varchar(255) NOT NULL,
  `is_advance_salary_deduct` int(11) NOT NULL,
  `advance_salary_amount` varchar(255) NOT NULL,
  `is_payment` tinyint(1) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `hourly_rate` varchar(255) NOT NULL,
  `total_hours_work` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`make_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_meetings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_meetings` (
  `meeting_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` varchar(255) DEFAULT NULL,
  `meeting_title` varchar(255) NOT NULL,
  `meeting_date` varchar(255) NOT NULL,
  `meeting_time` varchar(255) NOT NULL,
  `meeting_room` varchar(255) NOT NULL,
  `meeting_note` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_office_location`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_office_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `location_head` int(11) NOT NULL,
  `location_manager` int(11) NOT NULL,
  `location_name` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_office_location`
		--
		INSERT INTO `xin_office_location` (`location_id`, `company_id`, `location_head`, `location_manager`, `location_name`, `email`, `phone`, `fax`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `added_by`, `created_at`, `status`) VALUES
(1, 10, 0, 0, 'Office', 'CSS@gmail.com', 12345678, 12345678, '1 Yishun Industrial Street 1', '#07-36 A''Posh BizHub', 'Singapore', 'Singapore', 768160, 195, 1, '29-09-2023', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_office_shift`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_office_shift` (
  `office_shift_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `shift_name` varchar(255) NOT NULL,
  `default_shift` int(11) NOT NULL,
  `monday_in_time` varchar(222) NOT NULL,
  `monday_out_time` varchar(222) NOT NULL,
  `tuesday_in_time` varchar(222) NOT NULL,
  `tuesday_out_time` varchar(222) NOT NULL,
  `wednesday_in_time` varchar(222) NOT NULL,
  `wednesday_out_time` varchar(222) NOT NULL,
  `thursday_in_time` varchar(222) NOT NULL,
  `thursday_out_time` varchar(222) NOT NULL,
  `friday_in_time` varchar(222) NOT NULL,
  `friday_out_time` varchar(222) NOT NULL,
  `saturday_in_time` varchar(222) NOT NULL,
  `saturday_out_time` varchar(222) NOT NULL,
  `sunday_in_time` varchar(222) NOT NULL,
  `sunday_out_time` varchar(222) NOT NULL,
  `created_at` varchar(222) NOT NULL,
  PRIMARY KEY (`office_shift_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_office_shift`
		--
		INSERT INTO `xin_office_shift` (`office_shift_id`, `company_id`, `shift_name`, `default_shift`, `monday_in_time`, `monday_out_time`, `tuesday_in_time`, `tuesday_out_time`, `wednesday_in_time`, `wednesday_out_time`, `thursday_in_time`, `thursday_out_time`, `friday_in_time`, `friday_out_time`, `saturday_in_time`, `saturday_out_time`, `sunday_in_time`, `sunday_out_time`, `created_at`) VALUES
(1, 10, 'Morning Shift', 1, '08:00', '18:00', '08:00', '18:00', '08:00', '18:00', '08:00', '18:00', '08:00', '18:00', '', '', '', '', '2018-02-28');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_payment_deduction_types`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_payment_deduction_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_item_id` int(11) DEFAULT NULL,
  `payment_deduction_name` varchar(288) NOT NULL,
  `pd_type` int(11) NOT NULL COMMENT '1 = recurring payment\n2 = ad hoc payment\n3 = both',
  `cpf` tinyint(4) DEFAULT NULL,
  `tax` tinyint(4) DEFAULT NULL,
  `sdl` tinyint(4) DEFAULT NULL,
  `shg` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_payment_deduction_types`
		--
		INSERT INTO `xin_payment_deduction_types` (`id`, `payslip_item_id`, `payment_deduction_name`, `pd_type`, `cpf`, `tax`, `sdl`, `shg`, `created_at`, `updated_at`) VALUES
(1, '', 'Advance Pay', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(2, 2, 'Allowance', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(3, '', 'Annual Wage Supplement', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(4, '', 'Backdated Salary', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(5, '', 'Backdated Salary Increment', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(6, '', 'Basic Pay', 1, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(7, '', 'Benefits in Kind', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(8, '', 'Bonus', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(9, 5, 'Commission (Daily/Weekly/Monthly)', 1, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(10, 5, 'Commission (Irregular)', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(11, '', 'Compensation for loss of employment', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(12, '', 'Deduction', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(13, '', 'Deduction (from Net Salary)', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(14, '', 'Deduction (from Net Salary)(no SHG contribution)', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(15, '', 'Director fees', 3, '', 1, '', '', '2021-02-09 23:24:35', ''),
(16, 2, 'Extra Duty Allowance', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(17, 2, 'Festive Allowance', 2, 1, '', '', '', '2021-02-09 23:24:35', ''),
(18, '', 'Flexi-Benefit Childcare / Eldercare Fees For Dependants', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(19, '', 'Flexi-Benefit Dental Expenses For Dependants', 2, '', 1, 1, 1, '2021-02-09 23:24:35', ''),
(20, '', 'Flexi-Benefit Gym Membership', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(21, '', 'Flexi-Benefit Health Screening & Vaccinations', 2, '', '', 1, 1, '2021-02-09 23:24:35', ''),
(22, '', 'Flexi-Benefit Holiday Expenses', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(23, '', 'Flexi-Benefit Medical Expenses For Dependants', 2, '', 1, 1, 1, '2021-02-09 23:24:35', ''),
(24, '', 'Flexi-Benefit Optical Expenses', 2, '', 1, 1, 1, '2021-02-09 23:24:35', ''),
(25, '', 'Flexi-Benefit Personal Insurance', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(26, '', 'Flexi-Benefit TCM / CHIRO/ PHYSIO', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(27, '', 'Gifts in Kind', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(28, '', 'Gratuity', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(29, '', 'Gratuity paid for years of service', 2, '', 1, '', '', '2021-02-09 23:24:35', ''),
(30, 2, 'Housing/ Rental Allowance', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(31, '', 'Incentive', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(32, 2, 'Incentive Allowance', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(33, '', 'Leave Pay', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(34, 2, 'Meal Allowance', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(35, '', 'NS Leave Claims Deduction', 2, '', 1, '', '', '2021-02-09 23:24:35', ''),
(36, '', 'Onboarding incentive', 2, '', 1, '', '', '2021-02-09 23:24:35', ''),
(37, '', 'Others', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(38, '', 'Others(no gross)', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(39, 2, 'Per Diem Allowance', 3, 1, '', '', '', '2021-02-09 23:24:35', ''),
(40, '', 'Per Diem Reimbursement', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(41, '', 'Referral of Employees Fees', 2, '', 1, '', '', '2021-02-09 23:24:35', ''),
(42, '', 'Reimbursements', 2, '', '', '', '', '2021-02-09 23:24:35', ''),
(43, '', 'Salary in lieu', 2, '', 1, '', '', '2021-02-09 23:24:35', ''),
(44, '', 'Share Option Sale', 2, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(45, '', 'Termination Benefits', 2, '', 1, '', '', '2021-02-09 23:24:35', ''),
(46, '', 'Tips', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', ''),
(47, 2, 'Transport Allowance', 3, 1, 1, 1, 1, '2021-02-09 23:24:35', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_payment_method`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_payment_method` (
  `payment_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `method_name` varchar(255) NOT NULL,
  `payment_percentage` varchar(200) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_payment_method`
		--
		INSERT INTO `xin_payment_method` (`payment_method_id`, `company_id`, `method_name`, `payment_percentage`, `account_number`, `created_at`) VALUES
(1, 1, 'Cash', 30, '', '23-04-2018 05:13:52'),
(2, 1, 'Paypal', 40, 1, '12-08-2018 02:18:50'),
(3, 1, 'Bank', 30, 1231232, '12-08-2018 02:18:57');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_payroll_custom_fields`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_payroll_custom_fields` (
  `payroll_custom_id` int(11) NOT NULL AUTO_INCREMENT,
  `allow_custom_1` varchar(255) NOT NULL,
  `is_active_allow_1` int(11) NOT NULL,
  `allow_custom_2` varchar(255) NOT NULL,
  `is_active_allow_2` int(11) NOT NULL,
  `allow_custom_3` varchar(255) NOT NULL,
  `is_active_allow_3` int(11) NOT NULL,
  `allow_custom_4` varchar(255) NOT NULL,
  `is_active_allow_4` int(11) NOT NULL,
  `allow_custom_5` varchar(255) NOT NULL,
  `is_active_allow_5` int(11) NOT NULL,
  `deduct_custom_1` varchar(255) NOT NULL,
  `is_active_deduct_1` int(11) NOT NULL,
  `deduct_custom_2` varchar(255) NOT NULL,
  `is_active_deduct_2` int(11) NOT NULL,
  `deduct_custom_3` varchar(255) NOT NULL,
  `is_active_deduct_3` int(11) NOT NULL,
  `deduct_custom_4` varchar(255) NOT NULL,
  `is_active_deduct_4` int(11) NOT NULL,
  `deduct_custom_5` varchar(255) NOT NULL,
  `is_active_deduct_5` int(11) NOT NULL,
  PRIMARY KEY (`payroll_custom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_payslip_items`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_payslip_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(288) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_payslip_items`
		--
		INSERT INTO `xin_payslip_items` (`id`, `item_name`, `created_at`, `updated_at`) VALUES
(1, 'Basic Pay', '2021-02-09 23:24:35', ''),
(2, 'Allowance', '2021-02-09 23:24:35', ''),
(3, 'Payments', '2021-02-09 23:24:35', ''),
(4, 'Deductions', '2021-02-09 23:24:35', ''),
(5, 'Commission', '2021-02-09 23:24:35', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_appraisal`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_appraisal` (
  `performance_appraisal_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `appraisal_year_month` varchar(255) NOT NULL,
  `customer_experience` int(11) NOT NULL,
  `marketing` int(11) NOT NULL,
  `management` int(11) NOT NULL,
  `administration` int(11) NOT NULL,
  `presentation_skill` int(11) NOT NULL,
  `quality_of_work` int(11) NOT NULL,
  `efficiency` int(11) NOT NULL,
  `integrity` int(11) NOT NULL,
  `professionalism` int(11) NOT NULL,
  `team_work` int(11) NOT NULL,
  `critical_thinking` int(11) NOT NULL,
  `conflict_management` int(11) NOT NULL,
  `attendance` int(11) NOT NULL,
  `ability_to_meet_deadline` int(11) NOT NULL,
  `remarks` mediumtext NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`performance_appraisal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_performance_appraisal`
		--
		INSERT INTO `xin_performance_appraisal` (`performance_appraisal_id`, `company_id`, `employee_id`, `appraisal_year_month`, `customer_experience`, `marketing`, `management`, `administration`, `presentation_skill`, `quality_of_work`, `efficiency`, `integrity`, `professionalism`, `team_work`, `critical_thinking`, `conflict_management`, `attendance`, `ability_to_meet_deadline`, `remarks`, `added_by`, `created_at`) VALUES
(1, 10, 6, '2023-10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '&lt;p&gt;Good Job!&lt;/p&gt;', 1, '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_appraisal_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_appraisal_options` (
  `performance_appraisal_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `appraisal_id` int(11) NOT NULL,
  `appraisal_type` varchar(200) NOT NULL,
  `appraisal_option_id` int(11) NOT NULL,
  `appraisal_option_value` int(11) NOT NULL,
  PRIMARY KEY (`performance_appraisal_options_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

		--
		-- Dumping data for table `xin_performance_appraisal_options`
		--
		INSERT INTO `xin_performance_appraisal_options` (`performance_appraisal_options_id`, `appraisal_id`, `appraisal_type`, `appraisal_option_id`, `appraisal_option_value`) VALUES
(1, 1, 'technical', 0, 2),
(2, 1, 'technical', 1, 4),
(3, 1, 'technical', 2, 2),
(4, 1, 'organizational', 0, 8),
(5, 1, 'organizational', 1, 7),
(6, 1, 'organizational', 2, 7);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_indicator`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_indicator` (
  `performance_indicator_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `customer_experience` int(11) NOT NULL,
  `marketing` int(11) NOT NULL,
  `management` int(11) NOT NULL,
  `administration` int(11) NOT NULL,
  `presentation_skill` int(11) NOT NULL,
  `quality_of_work` int(11) NOT NULL,
  `efficiency` int(11) NOT NULL,
  `integrity` int(11) NOT NULL,
  `professionalism` int(11) NOT NULL,
  `team_work` int(11) NOT NULL,
  `critical_thinking` int(11) NOT NULL,
  `conflict_management` int(11) NOT NULL,
  `attendance` int(11) NOT NULL,
  `ability_to_meet_deadline` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`performance_indicator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_performance_indicator`
		--
		INSERT INTO `xin_performance_indicator` (`performance_indicator_id`, `company_id`, `designation_id`, `customer_experience`, `marketing`, `management`, `administration`, `presentation_skill`, `quality_of_work`, `efficiency`, `integrity`, `professionalism`, `team_work`, `critical_thinking`, `conflict_management`, `attendance`, `ability_to_meet_deadline`, `added_by`, `created_at`) VALUES
(1, 10, 17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '02-10-2023');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_indicator_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_indicator_options` (
  `performance_indicator_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_id` int(11) NOT NULL,
  `indicator_type` varchar(200) NOT NULL,
  `indicator_option_id` int(11) NOT NULL,
  `indicator_option_value` int(11) NOT NULL,
  PRIMARY KEY (`performance_indicator_options_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

		--
		-- Dumping data for table `xin_performance_indicator_options`
		--
		INSERT INTO `xin_performance_indicator_options` (`performance_indicator_options_id`, `indicator_id`, `indicator_type`, `indicator_option_id`, `indicator_option_value`) VALUES
(1, 1, 'technical', 0, 3),
(2, 1, 'technical', 1, 3),
(3, 1, 'technical', 2, 3),
(4, 1, 'organizational', 0, 7),
(5, 1, 'organizational', 1, 7),
(6, 1, 'organizational', 2, 8);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_person_id_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_person_id_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_name` varchar(128) NOT NULL,
  `iras_code` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_person_id_type`
		--
		INSERT INTO `xin_person_id_type` (`id`, `id_name`, `iras_code`, `created_at`, `updated_at`) VALUES
(1, 'NRIC', 1, '2021-02-09 23:24:35', ''),
(2, 'FIN', 2, '2021-02-09 23:24:35', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_project_variations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_project_variations` (
  `variation_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `variation_name` varchar(255) NOT NULL,
  `variation_no` varchar(255) NOT NULL,
  `assigned_to` varchar(255) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `variation_hours` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `variation_status` int(11) NOT NULL,
  `client_approval` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`variation_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  `assigned_to` mediumtext NOT NULL,
  `priority` varchar(255) NOT NULL,
  `project_no` varchar(255) DEFAULT NULL,
  `phase_no` varchar(200) DEFAULT NULL,
  `purchase_no` varchar(200) DEFAULT NULL,
  `budget_hours` varchar(255) DEFAULT NULL,
  `summary` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `added_by` int(11) NOT NULL,
  `project_progress` varchar(255) NOT NULL,
  `project_note` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_attachment` (
  `project_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `upload_by` int(11) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`project_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_bugs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_bugs` (
  `bug_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attachment_file` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_discussion`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_discussion` (
  `discussion_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `attachment_file` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`discussion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_timelogs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_timelogs` (
  `timelogs_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `total_hours` varchar(255) NOT NULL,
  `timelogs_memo` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`timelogs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_qualification_education_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_qualification_education_level` (
  `education_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`education_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_qualification_education_level`
		--
		INSERT INTO `xin_qualification_education_level` (`education_level_id`, `company_id`, `name`, `created_at`) VALUES
(1, 1, 'High School Diploma / GED', '09-05-2018 03:11:59'),
(2, 0, 'M.A.', '01-09-2022 01:57:51'),
(3, 0, 'Diploma', '29-09-2023 08:21:10'),
(4, 0, 'Olevel', '02-10-2023 01:18:46');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_qualification_language`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_qualification_language` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_qualification_language`
		--
		INSERT INTO `xin_qualification_language` (`language_id`, `company_id`, `name`, `created_at`) VALUES
(1, 1, 'English', '09-05-2018 03:12:03'),
(2, 0, 'Chinese', '01-09-2022 01:58:03'),
(3, 0, 'Malay', '27-09-2023 02:07:26');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_qualification_skill`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_qualification_skill` (
  `skill_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`skill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_qualification_skill`
		--
		INSERT INTO `xin_qualification_skill` (`skill_id`, `company_id`, `name`, `created_at`) VALUES
(1, 0, 'PPT', '26-09-2023 07:26:53'),
(6, 0, 'Words', '05-10-2023 08:19:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_quoted_projects`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_quoted_projects` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `estimate_date` varchar(255) NOT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  `assigned_to` mediumtext NOT NULL,
  `priority` varchar(255) NOT NULL,
  `project_no` varchar(255) DEFAULT NULL,
  `phase_no` varchar(200) DEFAULT NULL,
  `estimate_hrs` varchar(255) DEFAULT NULL,
  `summary` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `added_by` int(11) NOT NULL,
  `project_progress` varchar(255) NOT NULL,
  `project_note` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_quoted_projects_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_quoted_projects_attachment` (
  `project_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `upload_by` int(11) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`project_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_quoted_projects_discussion`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_quoted_projects_discussion` (
  `discussion_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `attachment_file` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`discussion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_quoted_projects_timelogs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_quoted_projects_timelogs` (
  `timelogs_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `total_hours` varchar(255) NOT NULL,
  `timelogs_memo` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`timelogs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_recruitment_pages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_recruitment_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_details` mediumtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_recruitment_pages`
		--
		INSERT INTO `xin_recruitment_pages` (`page_id`, `page_title`, `page_details`, `status`, `created_at`) VALUES
(1, 'Pages', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(2, 'About Us', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(3, 'Career Services', 'Career Services', 1, ''),
(4, 'Success Stories', 'Success Stories', 1, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_recruitment_subpages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_recruitment_subpages` (
  `subpages_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `sub_page_title` varchar(255) NOT NULL,
  `sub_page_details` mediumtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`subpages_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_recruitment_subpages`
		--
		INSERT INTO `xin_recruitment_subpages` (`subpages_id`, `page_id`, `sub_page_title`, `sub_page_details`, `status`, `created_at`) VALUES
(1, 1, 'Sub Menu 1', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(2, 1, 'Sub Menu 2', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(3, 1, 'Sub Menu 3', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(4, 1, 'Sub Menu 4', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(5, 1, 'Sub Menu 5', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(6, 1, 'Sub Menu 6', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_allowances`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_allowances` (
  `allowance_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `payment_type_id` int(11) NOT NULL,
  `allowance_title` varchar(200) DEFAULT NULL,
  `allowance_amount` varchar(200) DEFAULT NULL,
  `salary_month` varchar(250) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`allowance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_allowances`
		--
		INSERT INTO `xin_salary_allowances` (`allowance_id`, `employee_id`, `payment_type_id`, `allowance_title`, `allowance_amount`, `salary_month`, `created_at`, `updated_at`) VALUES
(1, 3, 16, 'Extra Duty Allowance', 100, '', '2023-09-14 04:22:38', ''),
(5, 30, 2, 'Allowance', 300, '', '2023-02-22 23:25:32', ''),
(6, 31, 47, 'Transport Allowance', 100, '', '2023-02-22 23:40:52', ''),
(7, 35, 47, 'Transport Allowance', 50, '', '2023-02-23 02:50:42', ''),
(8, 38, 47, 'Transport Allowance', 100, '', '2023-02-23 03:09:56', ''),
(9, 39, 47, 'Transport Allowance', 100, '', '2023-02-23 03:23:37', ''),
(10, 42, 47, 'Transport Allowance', 200, '', '2023-02-23 04:33:14', ''),
(16, 60, 2, 'Allowance', 250, '', '2023-03-06 02:58:16', ''),
(17, 60, 47, 'Transport Allowance', 150, '', '2023-03-06 02:58:26', ''),
(18, 65, 47, 'Transport Allowance', 50, '', '2023-03-07 23:06:15', ''),
(19, 68, 47, 'Transport Allowance', 150, '', '2023-03-08 04:58:45', ''),
(20, 69, 47, 'Transport Allowance', 100, '', '2023-03-08 20:55:29', ''),
(21, 76, 47, 'Transport Allowance', 100, '', '2023-03-08 21:56:07', ''),
(22, 84, 2, 'Allowance', 180, '', '2023-03-09 23:30:48', ''),
(23, 84, 47, 'Transport Allowance', 100, '', '2023-03-09 23:30:53', ''),
(24, 85, 2, 'Allowance', 200, '', '2023-03-09 23:38:06', ''),
(25, 85, 47, 'Transport Allowance', 200, '', '2023-03-09 23:38:11', ''),
(26, 86, 2, 'Allowance', 200, '', '2023-03-09 23:59:59', ''),
(27, 86, 47, 'Transport Allowance', 100, '', '2023-03-10 00:00:04', ''),
(28, 87, 2, 'Allowance', 150, '', '2023-03-10 04:29:02', ''),
(29, 87, 47, 'Transport Allowance', 100, '', '2023-03-10 04:29:06', ''),
(30, 89, 2, 'Allowance', 200, '', '2023-03-14 23:53:01', ''),
(31, 89, 47, 'Transport Allowance', 100, '', '2023-03-14 23:53:06', ''),
(32, 90, 2, 'Allowance', 150, '', '2023-03-15 00:31:24', ''),
(33, 90, 47, 'Transport Allowance', 100, '', '2023-03-15 00:31:28', ''),
(34, 91, 2, 'Allowance', 150, '', '2023-03-15 00:42:51', ''),
(35, 91, 47, 'Transport Allowance', 100, '', '2023-03-15 00:42:56', ''),
(36, 92, 2, 'Allowance', 200, '', '2023-03-15 00:51:27', ''),
(37, 92, 47, 'Transport Allowance', 100, '', '2023-03-15 00:51:32', ''),
(38, 93, 2, 'Allowance', 150, '', '2023-03-15 00:59:29', ''),
(39, 93, 47, 'Transport Allowance', 100, '', '2023-03-15 00:59:34', ''),
(40, 94, 2, 'Allowance', 100, '', '2023-03-15 01:21:23', ''),
(41, 94, 47, 'Transport Allowance', 100, '', '2023-03-15 01:21:26', ''),
(42, 88, 2, 'Allowance', 200, '', '2023-03-15 01:27:37', ''),
(43, 88, 47, 'Transport Allowance', 100, '', '2023-03-15 01:27:40', ''),
(44, 95, 2, 'Fixed Allowance', 200, '', '2023-03-15 23:30:21', ''),
(45, 95, 47, 'Transport Allowance', 100, '', '2023-03-15 23:30:30', ''),
(46, 96, 2, 'Fixed Allowance', 150, '', '2023-03-15 23:39:02', ''),
(47, 96, 47, 'Transport Allowance', 100, '', '2023-03-15 23:39:07', ''),
(48, 97, 2, 'Fixed Allowance', 150, '', '2023-03-15 23:49:16', ''),
(49, 97, 47, 'Transport Allowance', 200, '', '2023-03-15 23:49:22', ''),
(50, 98, 2, 'Fixed Allowance', 150, '', '2023-03-16 00:07:03', ''),
(51, 98, 47, 'Transport Allowance', 100, '', '2023-03-16 00:07:08', ''),
(52, 99, 2, 'Fixed Allowance', 150, '', '2023-03-16 00:20:53', ''),
(53, 99, 47, 'Transport Allowance', 100, '', '2023-03-16 00:20:58', ''),
(54, 100, 2, 'Fixed Allowance', 500, '', '2023-03-16 00:51:17', ''),
(55, 100, 47, 'Transport Allowance', 330, '', '2023-03-16 00:51:25', ''),
(56, 101, 2, 'Fixed Allowance', 500, '', '2023-03-16 01:01:03', ''),
(57, 101, 47, 'Transport Allowance', 380, '', '2023-03-16 01:01:12', ''),
(58, 102, 2, 'Fixed Allowance', 500, '', '2023-03-16 01:19:08', ''),
(59, 102, 47, 'Transport Allowance', 380, '', '2023-03-16 01:19:13', ''),
(60, 103, 2, 'Fixed Allowance', 450, '', '2023-03-16 01:41:09', ''),
(61, 104, 2, 'Fixed Allowance', 500, '', '2023-03-16 03:41:20', ''),
(62, 104, 47, 'Transport Allowance', 330, '', '2023-03-16 03:41:32', ''),
(63, 105, 2, 'Fixed Allowance', 300, '', '2023-03-16 04:04:19', ''),
(64, 105, 47, 'Transport Allowance', 230, '', '2023-03-16 04:04:25', ''),
(65, 106, 2, 'Fixed Allowance', 500, '', '2023-03-16 04:12:49', ''),
(66, 106, 47, 'Transport Allowance', 330, '', '2023-03-16 04:12:54', ''),
(67, 107, 2, 'Fixed Allowance', 300, '', '2023-03-16 04:21:01', ''),
(68, 107, 47, 'Transport Allowance', 230, '', '2023-03-16 04:21:11', ''),
(69, 108, 2, 'Fixed Allowance', 500, '', '2023-03-16 04:28:12', ''),
(70, 108, 47, 'Transport Allowance', 330, '', '2023-03-16 04:28:19', ''),
(71, 109, 2, 'Fixed Allowance', 300, '', '2023-03-16 04:43:11', ''),
(72, 109, 47, 'Transport Allowance', 230, '', '2023-03-16 04:43:18', ''),
(73, 110, 2, 'Fixed Allowance', 300, '', '2023-03-16 04:50:54', ''),
(74, 110, 47, 'Transport Allowance', 230, '', '2023-03-16 04:51:03', ''),
(75, 111, 2, 'Fixed Allowance', 300, '', '2023-03-16 05:22:04', ''),
(76, 111, 47, 'Transport Allowance', 230, '', '2023-03-16 05:22:12', ''),
(77, 112, 2, 'Fixed Allowance', 300, '', '2023-03-16 05:29:15', ''),
(78, 112, 47, 'Transport Allowance', 230, '', '2023-03-16 05:29:19', ''),
(79, 113, 2, 'Fixed Allowance', 500, '', '2023-03-16 05:36:10', ''),
(80, 114, 2, 'Fixed Allowance', 400, '', '2023-03-16 05:42:35', ''),
(81, 114, 47, 'Transport Allowance', 600, '', '2023-03-16 05:42:41', ''),
(82, 115, 2, 'Fixed Allowance', 500, '', '2023-03-16 22:01:13', ''),
(83, 116, 2, 'Fixed Allowance', 500, '', '2023-03-16 22:13:43', ''),
(84, 117, 2, 'Fixed Allowance', 400, '', '2023-03-16 22:26:24', ''),
(85, 117, 47, 'Transport Allowance', 800, '', '2023-03-16 22:26:32', ''),
(86, 118, 2, 'Fixed Allowance', 500, '', '2023-03-16 22:40:37', ''),
(87, 119, 2, 'Fixed Allowance', 500, '', '2023-03-16 22:59:41', ''),
(88, 120, 2, 'Fixed Allowance', 450, '', '2023-03-16 23:08:09', ''),
(89, 121, 2, 'Fixed Allowance', 450, '', '2023-03-16 23:23:36', ''),
(90, 122, 2, 'Fixed Allowance', 450, '', '2023-03-16 23:30:24', ''),
(91, 123, 2, 'Fixed Allowance', 450, '', '2023-03-16 23:38:34', ''),
(92, 124, 2, 'Fixed Allowance', 500, '', '2023-03-16 23:46:57', ''),
(93, 125, 2, 'Fixed Allowance', 450, '', '2023-03-16 23:53:01', ''),
(94, 126, 2, 'Fixed Allowance', 100, '', '2023-03-17 00:17:41', ''),
(95, 126, 47, 'Transport Allowance', 200, '', '2023-03-17 00:17:46', ''),
(96, 127, 2, 'Fixed Allowance', 50, '', '2023-03-17 00:28:43', ''),
(97, 127, 47, 'Transport Allowance', 300, '', '2023-03-17 00:28:57', ''),
(98, 128, 2, 'Fixed Allowance', 550, '', '2023-03-17 00:37:47', ''),
(99, 129, 2, 'Fixed Allowance', 300, '', '2023-03-17 00:45:44', ''),
(100, 130, 2, 'Fixed Allowance', 480, '', '2023-03-17 00:51:08', ''),
(101, 139, 16, 'Extra Duty Allowance', 100, '', '2023-04-19 06:59:28', ''),
(102, 139, 17, 'Festive Allowance', 50, '01-04-2023', '2023-04-19 06:59:33', ''),
(103, 141, 16, 'Extra Duty Allowance', 100, '', '2023-05-09 06:17:29', ''),
(104, 6, 30, 'Housing/ Rental Allowance', 100, '', '2023-10-01 23:40:17', ''),
(105, 6, 32, 'Incentive Allowance', 100, '01-10-2023', '2023-10-01 23:40:22', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_bank_allocation`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_bank_allocation` (
  `bank_allocation_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `pay_percent` varchar(200) NOT NULL,
  `acc_number` varchar(200) NOT NULL,
  PRIMARY KEY (`bank_allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_commissions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_commissions` (
  `salary_commissions_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `commission_type` int(11) NOT NULL,
  `commission_date` varchar(250) NOT NULL,
  `commission_amount` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`salary_commissions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_commissions`
		--
		INSERT INTO `xin_salary_commissions` (`salary_commissions_id`, `employee_id`, `commission_type`, `commission_date`, `commission_amount`, `created_at`, `updated_at`) VALUES
(3, 139, 9, '01-04-2023', 200, '2023-04-20 01:01:40', ''),
(4, 6, 9, '02-10-2023', 1000, '2023-10-01 21:25:19', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_loan_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_loan_deductions` (
  `loan_deduction_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `loan_options` int(11) NOT NULL,
  `loan_deduction_title` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `monthly_installment` varchar(200) NOT NULL,
  `loan_time` varchar(200) NOT NULL,
  `loan_deduction_amount` varchar(200) NOT NULL,
  `total_paid` varchar(200) NOT NULL,
  `reason` text NOT NULL,
  `status` int(11) NOT NULL,
  `is_deducted_from_salary` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`loan_deduction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_loan_deductions`
		--
		INSERT INTO `xin_salary_loan_deductions` (`loan_deduction_id`, `employee_id`, `loan_options`, `loan_deduction_title`, `start_date`, `end_date`, `monthly_installment`, `loan_time`, `loan_deduction_amount`, `total_paid`, `reason`, `status`, `is_deducted_from_salary`, `created_at`) VALUES
(1, 4, 0, 'Loan', '30-09-2023', '31-08-2024', 10000, 11, 909.09090909091, '', 'Loan', 0, 0, ''),
(3, 139, 1, 'loan1', '01-04-2023', '01-04-2024', 100, 12, 8.3333333333333, '', '', 0, 0, ''),
(4, 139, 0, 'loan2', '01-04-2022', '01-04-2023', 100, 12, 8.3333333333333, '', '', 0, 0, ''),
(5, 6, 2, 'hdb 5 room', '03-10-2023', '05-10-2023', 100, 0, 100, '', 'no money', 0, 0, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_other_payments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_other_payments` (
  `other_payments_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `payments_title` varchar(200) DEFAULT NULL,
  `payments_amount` varchar(200) DEFAULT NULL,
  `created_at` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`other_payments_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_other_payments`
		--
		INSERT INTO `xin_salary_other_payments` (`other_payments_id`, `employee_id`, `payments_title`, `payments_amount`, `created_at`) VALUES
(2, 139, 'pay1', 100, ''),
(3, 6, 'Other testing payment', 1000, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_overtime`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_overtime` (
  `salary_overtime_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `overtime_type` varchar(200) NOT NULL,
  `no_of_days` varchar(100) NOT NULL DEFAULT '0',
  `overtime_hours` varchar(100) NOT NULL DEFAULT '0',
  `overtime_rate` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`salary_overtime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_allowances`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_allowances` (
  `payslip_allowances_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `allowance_title` varchar(200) NOT NULL,
  `allowance_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_allowances_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslip_allowances`
		--
		INSERT INTO `xin_salary_payslip_allowances` (`payslip_allowances_id`, `payslip_id`, `employee_id`, `allowance_title`, `allowance_amount`, `salary_month`, `created_at`) VALUES
(24, 14, 6, 'Housing/ Rental Allowance', 100, '10-2023', '05-10-2023 08:21:37'),
(25, 14, 6, 'Incentive Allowance', 100, '10-2023', '05-10-2023 08:21:37');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_commissions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_commissions` (
  `payslip_commissions_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `commission_id` int(11) NOT NULL,
  `commission_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_commissions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslip_commissions`
		--
		INSERT INTO `xin_salary_payslip_commissions` (`payslip_commissions_id`, `payslip_id`, `employee_id`, `commission_id`, `commission_amount`, `salary_month`, `created_at`) VALUES
(10, 14, 6, 9, 1000, '10-2023', '05-10-2023 08:21:37');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_leave_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_leave_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `salary_month` varchar(128) NOT NULL,
  `leave_date` date NOT NULL,
  `leave_amount` decimal(13,5) NOT NULL,
  `is_half` tinyint(4) NOT NULL,
  `total_leave_amount` decimal(13,5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslip_leave_deductions`
		--
		INSERT INTO `xin_salary_payslip_leave_deductions` (`id`, `payslip_id`, `employee_id`, `salary_month`, `leave_date`, `leave_amount`, `is_half`, `total_leave_amount`, `created_at`, `updated_at`) VALUES
(3, 14, 140, '05-2023', '2023-05-15', 4.35000, 0, 4.35000, '2023-05-11 05:56:46', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_loan`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_loan` (
  `payslip_loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `loan_title` varchar(200) NOT NULL,
  `loan_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_loan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslip_loan`
		--
		INSERT INTO `xin_salary_payslip_loan` (`payslip_loan_id`, `payslip_id`, `employee_id`, `loan_title`, `loan_amount`, `salary_month`, `created_at`) VALUES
(14, 14, 6, 'hdb 5 room', 100, '10-2023', '05-10-2023 08:21:37');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_other_payments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_other_payments` (
  `payslip_other_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `payments_title` varchar(200) NOT NULL,
  `payments_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_other_payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslip_other_payments`
		--
		INSERT INTO `xin_salary_payslip_other_payments` (`payslip_other_payment_id`, `payslip_id`, `employee_id`, `payments_title`, `payments_amount`, `salary_month`, `created_at`) VALUES
(12, 14, 6, 'Other testing payment', 1000, '10-2023', '05-10-2023 08:21:37');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_overtime`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_overtime` (
  `payslip_overtime_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `overtime_salary_month` varchar(200) NOT NULL,
  `overtime_no_of_days` varchar(200) NOT NULL,
  `overtime_hours` varchar(200) NOT NULL,
  `overtime_rate` varchar(200) NOT NULL,
  `total_overtime` decimal(13,2) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_overtime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_share_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_share_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `amount` decimal(13,5) NOT NULL,
  `salary_month` varchar(128) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslip_share_options`
		--
		INSERT INTO `xin_salary_payslip_share_options` (`id`, `payslip_id`, `employee_id`, `amount`, `salary_month`, `created_at`, `updated_at`) VALUES
(1, 7, 139, 10.00000, '04-2023', '2023-04-20 01:03:05', ''),
(2, 1, 6, 0.00000, '10-2023', '2023-10-01 21:51:37', ''),
(3, 2, 6, 0.00000, '10-2023', '2023-10-02 23:46:56', ''),
(4, 3, 6, 0.00000, '10-2023', '2023-10-04 23:33:23', ''),
(5, 4, 6, 0.00000, '10-2023', '2023-10-04 23:33:55', ''),
(6, 6, 6, 0.00000, '10-2023', '2023-10-05 03:48:19', ''),
(7, 8, 6, 0.00000, '10-2023', '2023-10-05 03:49:18', ''),
(8, 10, 6, 0.00000, '10-2023', '2023-10-05 04:21:17', ''),
(9, 12, 6, 0.00000, '10-2023', '2023-10-05 04:21:35', ''),
(10, 14, 6, 0.00000, '10-2023', '2023-10-05 04:21:37', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_statutory_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_statutory_deductions` (
  `payslip_deduction_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `deduction_title` varchar(200) NOT NULL,
  `deduction_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_deduction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslips`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslips` (
  `payslip_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_key` varchar(200) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `wages_type` int(11) NOT NULL,
  `payslip_type` varchar(50) NOT NULL,
  `basic_salary` varchar(200) NOT NULL,
  `daily_wages` varchar(200) NOT NULL,
  `is_half_monthly_payroll` tinyint(1) NOT NULL,
  `hours_worked` varchar(50) NOT NULL DEFAULT '0',
  `total_allowances` varchar(200) NOT NULL,
  `total_commissions` varchar(200) NOT NULL,
  `total_statutory_deductions` varchar(200) NOT NULL,
  `total_other_payments` varchar(200) NOT NULL,
  `total_loan` varchar(200) NOT NULL,
  `total_overtime` varchar(200) NOT NULL,
  `statutory_deductions` varchar(200) NOT NULL,
  `gross_salary` decimal(13,2) NOT NULL,
  `net_salary` decimal(13,2) NOT NULL,
  `grand_net_salary` varchar(200) NOT NULL,
  `other_payment` varchar(200) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `pay_comments` mediumtext NOT NULL,
  `is_payment` int(11) NOT NULL,
  `year_to_date` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_payslips`
		--
		INSERT INTO `xin_salary_payslips` (`payslip_id`, `payslip_key`, `employee_id`, `department_id`, `company_id`, `location_id`, `designation_id`, `salary_month`, `wages_type`, `payslip_type`, `basic_salary`, `daily_wages`, `is_half_monthly_payroll`, `hours_worked`, `total_allowances`, `total_commissions`, `total_statutory_deductions`, `total_other_payments`, `total_loan`, `total_overtime`, `statutory_deductions`, `gross_salary`, `net_salary`, `grand_net_salary`, `other_payment`, `payment_method`, `pay_comments`, `is_payment`, `year_to_date`, `status`, `created_at`) VALUES
(14, 'kWa0NHZdgnF9QBcb5C7pPThsAjYE31tumLevzKIM', 6, 14, 10, 0, 17, '10-2023', 1, 'full_monthly', 50000, '', 0, 0, 200, 1000, 0, 1000, 100, 0, '', 52200.00, 50880.00, '', '', 0, '', 1, '05-10-2023', 0, '05-10-2023 08:21:37'),
(15, 'WwFs1K94NDVInZbiRYEJHlSo3AB7CTgyUvdfXLP6', 7, 14, 10, 0, 17, '10-2023', 1, 'full_monthly', 1000, '', 0, 0, 0, 0, 0, 0, 0, 0, '', 1000.00, 1000.00, '', '', 0, '', 1, '05-10-2023', 0, '05-10-2023 08:21:37');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_statutory_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_statutory_deductions` (
  `statutory_deductions_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `statutory_options` int(11) NOT NULL,
  `deduction_title` varchar(200) DEFAULT NULL,
  `deduction_amount` varchar(200) DEFAULT NULL,
  `created_at` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`statutory_deductions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_statutory_deductions`
		--
		INSERT INTO `xin_salary_statutory_deductions` (`statutory_deductions_id`, `employee_id`, `statutory_options`, `deduction_title`, `deduction_amount`, `created_at`) VALUES
(2, 110, 2, 'health', 10, ''),
(3, 139, 1, 'aaa', 2, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_templates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_templates` (
  `salary_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `salary_grades` varchar(255) NOT NULL,
  `basic_salary` varchar(255) NOT NULL,
  `overtime_rate` varchar(255) NOT NULL,
  `house_rent_allowance` varchar(255) NOT NULL,
  `medical_allowance` varchar(255) NOT NULL,
  `travelling_allowance` varchar(255) NOT NULL,
  `dearness_allowance` varchar(255) NOT NULL,
  `security_deposit` varchar(255) NOT NULL,
  `provident_fund` varchar(255) NOT NULL,
  `tax_deduction` varchar(255) NOT NULL,
  `gross_salary` varchar(255) NOT NULL,
  `total_allowance` varchar(255) NOT NULL,
  `total_deduction` varchar(255) NOT NULL,
  `net_salary` varchar(255) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`salary_template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_salary_templates`
		--
		INSERT INTO `xin_salary_templates` (`salary_template_id`, `company_id`, `salary_grades`, `basic_salary`, `overtime_rate`, `house_rent_allowance`, `medical_allowance`, `travelling_allowance`, `dearness_allowance`, `security_deposit`, `provident_fund`, `tax_deduction`, `gross_salary`, `total_allowance`, `total_deduction`, `net_salary`, `added_by`, `created_at`) VALUES
(1, 1, 'Monthly', 2500, '', 50, 60, 70, 80, 40, 20, 30, 2760, 260, 90, 2670, 1, '22-03-2018 01:40:06');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_security_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_security_level` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_security_level`
		--
		INSERT INTO `xin_security_level` (`type_id`, `name`, `created_at`) VALUES
(2, 'Security Type 2', '02-10-2023 01:37:11'),
(3, 'Security Type 3', '02-10-2023 01:37:13');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_share_option_scheme`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_share_option_scheme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_shortname` varchar(45) DEFAULT NULL,
  `scheme_fullname` varchar(128) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_share_option_scheme`
		--
		INSERT INTO `xin_share_option_scheme` (`id`, `scheme_shortname`, `scheme_fullname`, `created_at`, `updated_at`) VALUES
(1, 'EEBR', 'Employee Equity-Based Remuneration', '2021-02-09 23:24:35', ''),
(2, 'ERIS SME', 'Equity Remuneration Incentive Scheme (ERIS) SMEs', '2021-02-09 23:24:35', ''),
(3, 'ERIS All Corporations', 'Equity Remuneration Incentive Scheme (ERIS) All Corporations', '2021-02-09 23:24:35', ''),
(4, 'ERIS Start-Ups', 'Equity Remuneration Incentive Scheme (ERIS) Start-Ups', '2021-02-09 23:24:35', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_sub_departments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_sub_departments` (
  `sub_department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`sub_department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_sub_departments`
		--
		INSERT INTO `xin_sub_departments` (`sub_department_id`, `department_id`, `department_name`, `created_at`) VALUES
(8, 5, 'Management', '2022-11-30 12:37:47'),
(9, 6, 'Supervisor', '2023-02-17 11:06:33'),
(12, 14, 'Junior Accountants', '2023-10-02 01:13:05');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_support_ticket_files`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_support_ticket_files` (
  `ticket_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `ticket_files` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`ticket_file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_support_tickets`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_support_tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `ticket_code` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `ticket_priority` varchar(255) NOT NULL,
  `department_id` int(11) NOT NULL,
  `assigned_to` mediumtext NOT NULL,
  `message` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `ticket_remarks` mediumtext NOT NULL,
  `ticket_status` varchar(200) NOT NULL,
  `ticket_note` mediumtext NOT NULL,
  `is_notify` int(11) NOT NULL,
  `ticket_image` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_support_tickets_employees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_support_tickets_employees` (
  `tickets_employees_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`tickets_employees_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_system_setting`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_system_setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `application_name` varchar(255) NOT NULL,
  `default_currency` varchar(255) NOT NULL,
  `default_currency_id` int(11) NOT NULL,
  `default_currency_symbol` varchar(255) NOT NULL,
  `show_currency` varchar(255) NOT NULL,
  `currency_position` varchar(255) NOT NULL,
  `notification_position` varchar(255) NOT NULL,
  `notification_close_btn` varchar(255) NOT NULL,
  `notification_bar` varchar(255) NOT NULL,
  `enable_registration` varchar(255) NOT NULL,
  `login_with` varchar(255) NOT NULL,
  `date_format_xi` varchar(255) NOT NULL,
  `employee_manage_own_contact` varchar(255) NOT NULL,
  `employee_manage_own_profile` varchar(255) NOT NULL,
  `employee_manage_own_qualification` varchar(255) NOT NULL,
  `employee_manage_own_work_experience` varchar(255) NOT NULL,
  `employee_manage_own_document` varchar(255) NOT NULL,
  `employee_manage_own_picture` varchar(255) NOT NULL,
  `employee_manage_own_social` varchar(255) NOT NULL,
  `employee_manage_own_bank_account` varchar(255) NOT NULL,
  `enable_attendance` varchar(255) NOT NULL,
  `enable_clock_in_btn` varchar(255) NOT NULL,
  `enable_email_notification` varchar(255) NOT NULL,
  `payroll_include_day_summary` varchar(255) NOT NULL,
  `payroll_include_hour_summary` varchar(255) NOT NULL,
  `payroll_include_leave_summary` varchar(255) NOT NULL,
  `enable_job_application_candidates` varchar(255) NOT NULL,
  `job_logo` varchar(255) NOT NULL,
  `payroll_logo` varchar(255) NOT NULL,
  `is_payslip_password_generate` int(11) NOT NULL,
  `payslip_password_format` varchar(255) NOT NULL,
  `enable_profile_background` varchar(255) NOT NULL,
  `enable_policy_link` varchar(255) NOT NULL,
  `enable_layout` varchar(255) NOT NULL,
  `job_application_format` mediumtext NOT NULL,
  `technical_competencies` text DEFAULT NULL,
  `organizational_competencies` text DEFAULT NULL,
  `project_email` varchar(255) NOT NULL,
  `holiday_email` varchar(255) NOT NULL,
  `leave_email` varchar(255) NOT NULL,
  `payslip_email` varchar(255) NOT NULL,
  `award_email` varchar(255) NOT NULL,
  `recruitment_email` varchar(255) NOT NULL,
  `announcement_email` varchar(255) NOT NULL,
  `training_email` varchar(255) NOT NULL,
  `task_email` varchar(255) NOT NULL,
  `compact_sidebar` varchar(255) NOT NULL,
  `fixed_header` varchar(255) NOT NULL,
  `fixed_sidebar` varchar(255) NOT NULL,
  `boxed_wrapper` varchar(255) NOT NULL,
  `layout_static` varchar(255) NOT NULL,
  `system_skin` varchar(255) NOT NULL,
  `animation_effect` varchar(255) NOT NULL,
  `animation_effect_modal` varchar(255) NOT NULL,
  `animation_effect_topmenu` varchar(255) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `is_ssl_available` varchar(50) NOT NULL,
  `is_active_sub_departments` varchar(10) NOT NULL,
  `default_language` varchar(200) NOT NULL,
  `statutory_fixed` varchar(100) NOT NULL,
  `system_timezone` varchar(200) NOT NULL,
  `system_ip_address` varchar(255) NOT NULL,
  `system_ip_restriction` varchar(200) NOT NULL,
  `google_maps_api_key` mediumtext NOT NULL,
  `module_recruitment` varchar(100) NOT NULL,
  `module_travel` varchar(100) NOT NULL,
  `module_performance` varchar(100) NOT NULL,
  `module_payroll` varchar(10) NOT NULL,
  `module_files` varchar(100) NOT NULL,
  `module_awards` varchar(100) NOT NULL,
  `module_training` varchar(100) NOT NULL,
  `module_inquiry` varchar(100) NOT NULL,
  `module_language` varchar(100) NOT NULL,
  `module_orgchart` varchar(100) NOT NULL,
  `module_accounting` varchar(111) NOT NULL,
  `module_events` varchar(100) NOT NULL,
  `module_goal_tracking` varchar(100) NOT NULL,
  `module_assets` varchar(100) NOT NULL,
  `module_projects_tasks` varchar(100) NOT NULL,
  `module_chat_box` varchar(100) NOT NULL,
  `enable_page_rendered` varchar(255) NOT NULL,
  `enable_current_year` varchar(255) NOT NULL,
  `employee_login_id` varchar(200) NOT NULL,
  `paypal_email` varchar(100) NOT NULL,
  `paypal_sandbox` varchar(10) NOT NULL,
  `paypal_active` varchar(10) NOT NULL,
  `stripe_secret_key` varchar(200) NOT NULL,
  `stripe_publishable_key` varchar(200) NOT NULL,
  `stripe_active` varchar(10) NOT NULL,
  `online_payment_account` int(11) NOT NULL,
  `is_half_monthly` tinyint(1) NOT NULL,
  `half_deduct_month` tinyint(1) NOT NULL,
  `invoice_terms_condition` text DEFAULT NULL,
  `estimate_terms_condition` text DEFAULT NULL,
  `staff_dashboard` int(11) DEFAULT NULL,
  `project_dashboard` int(11) DEFAULT NULL,
  `enable_auth_background` varchar(11) NOT NULL,
  `hr_version` varchar(200) NOT NULL,
  `hr_release_date` varchar(100) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_system_setting`
		--
		INSERT INTO `xin_system_setting` (`setting_id`, `application_name`, `default_currency`, `default_currency_id`, `default_currency_symbol`, `show_currency`, `currency_position`, `notification_position`, `notification_close_btn`, `notification_bar`, `enable_registration`, `login_with`, `date_format_xi`, `employee_manage_own_contact`, `employee_manage_own_profile`, `employee_manage_own_qualification`, `employee_manage_own_work_experience`, `employee_manage_own_document`, `employee_manage_own_picture`, `employee_manage_own_social`, `employee_manage_own_bank_account`, `enable_attendance`, `enable_clock_in_btn`, `enable_email_notification`, `payroll_include_day_summary`, `payroll_include_hour_summary`, `payroll_include_leave_summary`, `enable_job_application_candidates`, `job_logo`, `payroll_logo`, `is_payslip_password_generate`, `payslip_password_format`, `enable_profile_background`, `enable_policy_link`, `enable_layout`, `job_application_format`, `technical_competencies`, `organizational_competencies`, `project_email`, `holiday_email`, `leave_email`, `payslip_email`, `award_email`, `recruitment_email`, `announcement_email`, `training_email`, `task_email`, `compact_sidebar`, `fixed_header`, `fixed_sidebar`, `boxed_wrapper`, `layout_static`, `system_skin`, `animation_effect`, `animation_effect_modal`, `animation_effect_topmenu`, `footer_text`, `is_ssl_available`, `is_active_sub_departments`, `default_language`, `statutory_fixed`, `system_timezone`, `system_ip_address`, `system_ip_restriction`, `google_maps_api_key`, `module_recruitment`, `module_travel`, `module_performance`, `module_payroll`, `module_files`, `module_awards`, `module_training`, `module_inquiry`, `module_language`, `module_orgchart`, `module_accounting`, `module_events`, `module_goal_tracking`, `module_assets`, `module_projects_tasks`, `module_chat_box`, `enable_page_rendered`, `enable_current_year`, `employee_login_id`, `paypal_email`, `paypal_sandbox`, `paypal_active`, `stripe_secret_key`, `stripe_publishable_key`, `stripe_active`, `online_payment_account`, `is_half_monthly`, `half_deduct_month`, `invoice_terms_condition`, `estimate_terms_condition`, `staff_dashboard`, `project_dashboard`, `enable_auth_background`, `hr_version`, `hr_release_date`, `updated_at`) VALUES
(1, 'Mahan Manufacturing', 'SGD - S$', 1, 'SGD - S$', 'symbol', 'Prefix', 'toast-top-center', 'true', 'true', 'no', 'username', '', '', '', '', '', '', 'yes', 'yes', '', 'yes', '', 'yes', 'yes', 'yes', 'yes', '', 'job_logo_1686747372.jpg', 'payroll_logo_1686747379.jpg', 0, 'employee_id', 'yes', 'yes', 'yes', 'doc,docx,pdf', 'Customer Experience,Marketing,Administration', 'Professionalism,Integrity,Attendance', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'sidebar_layout_hrsale', '', 'fixed-sidebar', 'boxed_layout_hrsale', '', 'skin-default', 'fadeInDown', 'tada', 'tada', 'Mahan Manufacturing', '', 'yes', 'english', '', 'Asia/Singapore', '::1', '', 'AIzaSyB3gP8H3eypotNeoEtezbRiF_f8Zh_p4ck', '', 'true', '', 'yes', 'true', 'true', 'false', 'false', '', 'true', 'true', '', 'true', 'true', 'false', '', '', 'yes', 'email', 'hrsalesoft-facilitator@gmail.com', 'yes', 'yes', 'sk_test_2XEyr1hQFGByITfQjSwFqNtm', 'pk_test_zVFISCqeQPnniD0ywHBHikMd', 'yes', 1, 0, 1, '', '', 0, 0, '', '1.0.3', '2018-03-28', '2018-03-28 04:27:32');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_task_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_task_categories` (
  `task_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`task_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

		--
		-- Dumping data for table `xin_task_categories`
		--
		INSERT INTO `xin_task_categories` (`task_category_id`, `category_name`, `created_at`) VALUES
(5, 'Modelling', '17-12-2019 10:44:48'),
(6, 'Fabrication drawings', '17-12-2019 10:44:55'),
(7, 'Erection drawings', '17-12-2019 10:45:01'),
(8, 'As built drawings', '17-12-2019 10:45:06'),
(9, 'R & D and RFI Related', '17-12-2019 10:45:12'),
(10, 'Checking', '17-12-2019 10:45:22');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tasks`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `assigned_to` varchar(255) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `task_hour` varchar(200) NOT NULL,
  `task_progress` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `task_status` int(11) NOT NULL,
  `task_note` mediumtext NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tasks_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tasks_attachment` (
  `task_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `upload_by` int(11) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`task_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tasks_comments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tasks_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `task_comments` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tax_types`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tax_types` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_tax_types`
		--
		INSERT INTO `xin_tax_types` (`tax_id`, `name`, `rate`, `type`, `description`, `created_at`) VALUES
(1, 'No Tax', 0, 'fixed', 'test', '25-05-2018'),
(2, 'IVU', 2, 'fixed', 'test', '25-05-2018'),
(3, 'VAT', 5, 'percentage', 'testttt', '25-05-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_termination_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_termination_type` (
  `termination_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`termination_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_termination_type`
		--
		INSERT INTO `xin_termination_type` (`termination_type_id`, `company_id`, `type`, `created_at`) VALUES
(1, 1, 'Voluntary Termination', '22-03-2018 01:38:41'),
(2, 0, 'Permanent', '01-09-2022 01:58:56');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_theme_settings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_theme_settings` (
  `theme_settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `fixed_layout` varchar(200) NOT NULL,
  `fixed_footer` varchar(200) NOT NULL,
  `boxed_layout` varchar(200) NOT NULL,
  `page_header` varchar(200) NOT NULL,
  `footer_layout` varchar(200) NOT NULL,
  `statistics_cards` varchar(200) NOT NULL,
  `animation_style` varchar(100) NOT NULL,
  `theme_option` varchar(100) NOT NULL,
  `dashboard_option` varchar(100) NOT NULL,
  `dashboard_calendar` varchar(100) NOT NULL,
  `login_page_options` varchar(100) NOT NULL,
  `sub_menu_icons` varchar(100) NOT NULL,
  `statistics_cards_background` varchar(200) NOT NULL,
  `employee_cards` varchar(200) NOT NULL,
  `card_border_color` varchar(200) NOT NULL,
  `compact_menu` varchar(200) NOT NULL,
  `flipped_menu` varchar(200) NOT NULL,
  `right_side_icons` varchar(200) NOT NULL,
  `bordered_menu` varchar(200) NOT NULL,
  `form_design` varchar(200) NOT NULL,
  `is_semi_dark` int(11) NOT NULL,
  `semi_dark_color` varchar(200) NOT NULL,
  `top_nav_dark_color` varchar(200) NOT NULL,
  `menu_color_option` varchar(200) NOT NULL,
  `export_orgchart` varchar(100) NOT NULL,
  `export_file_title` mediumtext NOT NULL,
  `org_chart_layout` varchar(200) NOT NULL,
  `org_chart_zoom` varchar(100) NOT NULL,
  `org_chart_pan` varchar(100) NOT NULL,
  PRIMARY KEY (`theme_settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_theme_settings`
		--
		INSERT INTO `xin_theme_settings` (`theme_settings_id`, `fixed_layout`, `fixed_footer`, `boxed_layout`, `page_header`, `footer_layout`, `statistics_cards`, `animation_style`, `theme_option`, `dashboard_option`, `dashboard_calendar`, `login_page_options`, `sub_menu_icons`, `statistics_cards_background`, `employee_cards`, `card_border_color`, `compact_menu`, `flipped_menu`, `right_side_icons`, `bordered_menu`, `form_design`, `is_semi_dark`, `semi_dark_color`, `top_nav_dark_color`, `menu_color_option`, `export_orgchart`, `export_file_title`, `org_chart_layout`, `org_chart_zoom`, `org_chart_pan`) VALUES
(1, 'false', 'true', 'false', 'breadcrumb-light', 'footer-dark', 4, 'fadeInLeft', 'template_1', 'dashboard_2', 'true', 'login_page_2', 'fa-circle-o', '', '', '', 'true', 'false', 'false', 'false', 'basic_form', 1, 'bg-primary', 'bg-blue-grey', 'menu-dark', 'true', 'Mahan', 't2b', 'true', 'true');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tickets_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tickets_attachment` (
  `ticket_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `upload_by` int(11) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`ticket_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tickets_comments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tickets_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ticket_comments` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_trainers`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_trainers` (
  `trainer_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `expertise` mediumtext NOT NULL,
  `address` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`trainer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_training`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `training_type_id` int(11) NOT NULL,
  `trainer_option` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `finish_date` varchar(200) NOT NULL,
  `training_cost` varchar(200) NOT NULL,
  `training_status` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `performance` varchar(200) NOT NULL,
  `remarks` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_training_types`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_training_types` (
  `training_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`training_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_training_types`
		--
		INSERT INTO `xin_training_types` (`training_type_id`, `company_id`, `type`, `created_at`, `status`) VALUES
(1, 1, 'Job Training', '19-03-2018 06:45:47', 1),
(2, 1, 'Workshop', '19-03-2018 06:45:51', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_travel_arrangement_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_travel_arrangement_type` (
  `arrangement_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`arrangement_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_travel_arrangement_type`
		--
		INSERT INTO `xin_travel_arrangement_type` (`arrangement_type_id`, `company_id`, `type`, `status`, `created_at`) VALUES
(1, 1, 'Corporation', 1, '19-03-2018 08:45:17'),
(2, 1, 'Guest House', 1, '19-03-2018 08:45:27');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_user_roles`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_user_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `role_name` varchar(200) NOT NULL,
  `role_access` varchar(200) NOT NULL,
  `role_resources` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_user_roles`
		--
		INSERT INTO `xin_user_roles` (`role_id`, `company_id`, `role_name`, `role_access`, `role_resources`, `created_at`, `updated_at`) VALUES
(1, 1, 'Super Admin', 1, '0,103,13,13,201,202,203,372,373,393,393,394,395,396,422,351,421,88,23,23,204,205,206,231,400,22,12,14,14,207,208,209,232,15,15,210,211,212,233,16,16,213,214,215,234,406,407,408,17,17,216,217,218,235,18,18,219,220,221,236,19,19,222,223,224,237,20,20,225,226,227,238,21,21,228,229,230,239,2,3,3,240,241,242,4,4,243,244,245,249,5,5,246,247,248,6,6,250,251,252,11,11,254,255,256,257,9,9,258,259,260,96,24,25,25,262,263,264,265,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,423,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,48,49,49,291,292,293,50,51,51,294,295,387,52,52,296,297,388,32,36,36,313,314,404,405,40,41,41,298,299,300,301,42,42,302,303,304,305,43,43,306,307,308,309,104,44,44,315,316,317,318,312,45,45,319,320,321,322,122,122,331,332,333,106,107,107,334,335,336,108,108,338,339,340,47,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,57,60,61,118,62,63,93,71,286,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,37,37,391,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,89,89,370,371,90,91,94,95,92,110,111,112,113,114,115,116,117,409,429,428', '28-02-2018', ''),
(4, 0, 'Director', 1, '0,103,13,13,201,202,203,372,373,393,393,394,395,396,422,351,421,88,23,23,204,205,206,231,400,22,12,14,14,207,208,209,232,15,15,210,211,212,233,16,16,213,214,215,234,406,407,408,17,17,216,217,218,235,18,18,219,220,221,236,19,19,222,223,224,237,20,20,225,226,227,238,21,21,228,229,230,239,2,3,3,240,241,242,4,4,243,244,245,249,5,5,246,247,248,6,6,250,251,252,11,11,254,255,256,257,9,9,258,259,260,96,24,25,25,262,263,264,265,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,423,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,48,49,49,291,292,293,50,51,51,294,295,52,52,296,297,32,36,36,313,314,404,405,40,41,41,298,299,300,301,42,42,302,303,304,305,43,43,306,307,308,309,104,44,44,315,316,317,318,312,45,45,319,320,321,322,122,122,331,332,333,106,107,107,334,335,336,108,108,338,339,340,47,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,57,60,61,118,62,63,93,71,286,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,89,89,370,371,90,91,94,95,92,110,111,112,113,114,115,116,117,409', '25-11-2022', ''),
(6, 0, 'HR Department', 1, '0,103,13,13,201,202,203,372,373,393,393,394,395,396,422,351,421,88,23,23,204,205,206,231,400,22,12,14,14,207,208,209,232,15,15,210,211,212,233,16,16,213,214,215,234,406,407,408,17,17,216,217,218,235,18,18,219,220,221,236,19,19,222,223,224,237,20,20,225,226,227,238,21,21,228,229,230,239,2,3,3,240,241,242,4,4,243,244,245,249,5,5,246,247,248,6,6,250,251,252,11,11,254,255,256,257,9,9,258,259,260,96,24,25,25,262,263,264,265,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,423,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,48,49,49,291,292,293,50,51,51,294,295,52,52,296,297,32,36,36,313,314,404,405,40,41,41,298,299,300,301,42,42,302,303,304,305,43,43,306,307,308,309,104,44,44,315,316,317,318,312,45,45,319,320,321,322,122,122,331,332,333,106,107,107,334,335,336,108,108,338,339,340,47,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,57,60,61,118,62,63,93,71,286,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,89,89,370,371,90,91,94,95,92,110,111,112,113,114,115,116,117,409', '25-11-2022', ''),
(7, 0, 'Account Department', 2, '0,24,25,25,262,263,264,265,26,26,266,267,268,104,44,44,315,316,317,318,312,45,45,319,320,321,322,122,122,331,332,333,118,62,63,71,286,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,37,37,391,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,89,89,370,371,90,94', '25-11-2022', ''),
(9, 0, 'Operation Department', 2, '0,25,262,263,264,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,423,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,49,49,291,292,293,50,51,294,295,52,296,297,44,315,316,317,312,45,45,319,320,321,322,106,107,107,334,335,336,108,108,338,339,340,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,119,89,90,91,94', '25-11-2022', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_users`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role` varchar(30) NOT NULL DEFAULT 'administrator',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_logo` varchar(255) NOT NULL,
  `user_type` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_photo` varchar(255) NOT NULL,
  `profile_background` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_users`
		--
		INSERT INTO `xin_users` (`user_id`, `user_role`, `first_name`, `last_name`, `company_name`, `company_logo`, `user_type`, `email`, `username`, `password`, `profile_photo`, `profile_background`, `contact_number`, `gender`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `last_login_date`, `last_login_ip`, `is_logged_in`, `is_active`, `created_at`) VALUES
(1, 'administrator', 'Thomas', 'Fleming', '', '', 2, 'test1@test.com', 'admin', 'test123', 'user_1520720863.jpg', 'profile_background_1505458640.jpg', 12333332, 'Male', 'Address Line 1', 'Address Line 2', 'City', 'State', 12345, 230, '11-05-2023 12:22:50', '::1', 1, 1, '14-09-2017 10:02:54'),
(2, 'administrator', 'Main', 'Office', '', '', 2, 'test@test.com', 'test', 'test123', 'user_1523821315.jpg', '', 1234567890, 'Male', 'Address Line 1', 'Address Line 2', 'City', 'State', 11461, 190, '04-04-2022 13:13:38', '115.66.51.56', 1, 1, '15-04-2018 06:13:08'),
(4, 'administrator', 'Fiona', 'Grace', 'HRSALE', 'employer_1524025572.jpg', 1, 'employer@test.com', '', 'test123', '', '', 1234567890, 'Male', 'Address Line 1', 'Address Line 2', 'City', 'State', 11461, 190, '23-04-2018 05:34:54', '::1', 0, 1, '18-04-2018 07:26:12');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_warning_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_warning_type` (
  `warning_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`warning_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

		--
		-- Dumping data for table `xin_warning_type`
		--
		INSERT INTO `xin_warning_type` (`warning_type_id`, `company_id`, `type`, `created_at`) VALUES
(1, 1, 'First Warning', '22-03-2018 01:38:02');


		/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
		/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
		/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;